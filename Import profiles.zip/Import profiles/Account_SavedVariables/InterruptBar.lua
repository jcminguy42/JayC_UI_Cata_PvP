
InterruptBarDB = {
	["scale"] = 1,
	["lock"] = true,
	["hidden"] = true,
	["Position"] = {
		["yOfs"] = 220.5553555380773,
		["xOfs"] = -56.88885192938525,
		["point"] = "BOTTOM",
		["relativePoint"] = "BOTTOM",
	},
}
