
OmniCC4Config = {
	["version"] = "4.3.2",
	["groups"] = {
	},
	["groupSettings"] = {
		["base"] = {
			["styles"] = {
				["soon"] = {
					["scale"] = 1.399999976158142,
				},
			},
			["fontOutline"] = "THICKOUTLINE",
		},
	},
}
