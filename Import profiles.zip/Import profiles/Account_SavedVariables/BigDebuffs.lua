
BigDebuffsDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Jsea - Maelstrom"] = "Default",
		["Gsea - Maelstrom"] = "Default",
		["Gsee - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["spells"] = {
				[768] = {
				},
				[24858] = {
					["customPriority"] = false,
				},
				[783] = {
				},
				[5487] = {
				},
			},
			["unitFrames"] = {
				["party3"] = {
					["position"] = {
						"LEFT", -- [1]
						nil, -- [2]
						"LEFT", -- [3]
						339.3889444231267, -- [4]
						57.49988151910763, -- [5]
					},
				},
				["party"] = {
					["anchor"] = "manual",
				},
				["party4"] = {
					["position"] = {
						"LEFT", -- [1]
						nil, -- [2]
						"LEFT", -- [3]
						338.5000372368519, -- [4]
						-5.500070541437504, -- [5]
					},
				},
				["arena1"] = {
				},
				["party1"] = {
					["position"] = {
						"LEFT", -- [1]
						nil, -- [2]
						"LEFT", -- [3]
						336.7223279071022, -- [4]
						180.8332107036151, -- [5]
					},
				},
				["party2"] = {
					["position"] = {
						"LEFT", -- [1]
						nil, -- [2]
						"LEFT", -- [3]
						335.8334907493607, -- [4]
						116.9443065947662, -- [5]
					},
				},
			},
		},
	},
}
