
_detalhes_global = {
	["npcid_pool"] = {
		[46610] = "Twilight Miner",
		[30514] = "GothBoi",
		[2042] = "Nightsaber",
		[19373] = "Thanos <Boula>",
		[49008] = "Axebite Infantry",
		[20444] = "Ango'rosh Shadowmage",
		[4112] = "Thulnak",
		[15409] = "Nalkin",
		[29827] = "Juk'dok",
		[6194] = "Wraatom",
		[27829] = "Ebon Gargoyle <Tortura>",
		[42359] = "Okril'lon Infantry",
		[38299] = "Water Elemental",
		[27893] = "Rune Weapon <Elfmaid>",
		[9359] = "Monkey",
		[6222] = "Leprous Technician",
		[6226] = "Mechano-Flamewalker",
		[6230] = "Peacekeeper Security Suit",
		[6234] = "Mechanized Guardian",
		[31058] = "Two <Itsdamplay>",
		[26982] = "Keanoreevez <Keanoreevez>",
		[39642] = "Hovel Brute",
		[7273] = "Cat",
		[3131] = "Water Elemental <Lunchspecial>",
		[44885] = "Bound Air Elemental",
		[34687] = "Carrionbreaker",
		[46004] = "Rhonda Molver",
		[23034] = "Carrioncatcher <Lja>",
		[30243] = "Wolf",
		[16960] = "Sister of Grief",
		[7325] = "Monkey <Dyrocheck>",
		[44214] = "Flaming Orb",
		[34016] = "jerry",
		[8528] = "Dread Weaver",
		[13651] = "Hammerkeeper",
		[30371] = "Steven <Slanginslugz>",
		[12668] = "Drusnlissa",
		[8600] = "Plaguebat",
		[32593] = "Skittering Swarmer",
		[29540] = "Spinemasher",
		[39643] = "Hovel Shadowcaster",
		[53006] = "Spirit Link Totem <Viberly>",
		[42808] = "Stonecore Flayer",
		[44886] = "Bound Water Elemental",
		[19422] = "Bleeding Hollow Necrolyte",
		[30707] = "Young Dragonhawk",
		[8720] = "Raptor",
		[40986] = "Stonefeeder",
		[19502] = "Monkey",
		[44151] = "Bouldergut",
		[14898] = "MonkiJames",
		[41146] = "Frostmane Scavenger",
		[45334] = "Twilight Bonebreaker",
		[42297] = "Shadowsworn Occultist",
		[40283] = "Water Elemental",
		[47476] = "Gloomwing",
		[9863] = "Monkey",
		[27031] = "Water Elemental",
		[44855] = "Twilight Cryptomancer",
		[44887] = "Bound Fire Elemental",
		[26072] = "Gravefeeder",
		[42937] = "Blackrock Invader",
		[2248] = "Cave Yeti",
		[18975] = "Wrathguard",
		[38973] = "Spider",
		[50258] = "Frostmaul Tumbler",
		[49267] = "Crystal Shard",
		[50322] = "Arcane Mana-Cluster",
		[24170] = "Water Elemental",
		[20094] = "Un",
		[18080] = "Kataru",
		[4540] = "Scarlet Monk",
		[19199] = "Wormgnaw",
		[46582] = "Hungry Ghoul",
		[41563] = "Shadowflame Master",
		[25417] = "Raging Boiler",
		[47765] = "Glopgut Pounder",
		[47829] = "Fel Flames",
		[46838] = "Subjugated Firestarter",
		[42810] = "Crystalspawn Giant",
		[22476] = "Monkey",
		[51090] = "Singing Sunflower",
		[26616] = "Blighted Elk",
		[26632] = "Crab <Zuul>",
		[19519] = "Starving Bog Lord",
		[45240] = "Forsaken Trooper",
		[8273] = "Marrowgrinder",
		[42299] = "Water Elemental <Twphx>",
		[44473] = "Shaggy Black Bear",
		[20734] = "one",
		[50675] = "Ebon Imp <President>",
		[41500] = "Twilight Scorchlord",
		[20798] = "Razorsaw",
		[7777] = "Flaaghun",
		[14531] = "Water Elemental",
		[29062] = "Anub'ar Champion",
		[5743] = "Monkey",
		[13532] = "TOXIC",
		[32179] = "Braingnaw",
		[36865] = "Wormkeeper",
		[20079] = "Darkcrest Sentry",
		[2390] = "Haatom <Athene>",
		[7849] = "Mobile Alert System",
		[19136] = "Flamewaker Imp",
		[4812] = "Twilight Loreseeker",
		[41501] = "Fiery Minion",
		[4820] = "Blindlight Oracle",
		[24379] = "Wolf",
		[25418] = "Churn",
		[4832] = "Twilight Lord Kelris",
		[23452] = "Monkey <Ateenaa>",
		[33637] = "Wolf",
		[19440] = "Eye of Grillok",
		[43995] = "Needlerock Mystic",
		[19504] = "Monkey <Vanahimm>",
		[39040] = "Liz",
		[45242] = "Forsaken Trooper",
		[5927] = "Elemental Resistance Totem <Xcite>",
		[44315] = "Desiccated Magus",
		[12893] = "Rhuuzhum",
		[10855] = "Young Wolf",
		[16611] = "Monkey",
		[43484] = "Fungal Growth II <Ovl>",
		[47608] = "Horde Mage Infantry",
		[4948] = "Young Wolf",
		[5975] = "Dreadmaul Ogre Mage",
		[18337] = "Batslicer",
		[5983] = "Bonepicker",
		[35558] = "Cat <Fufurufa>",
		[20863] = "Pigrin",
		[29063] = "Anub'ar Crypt Fiend",
		[43158] = "Mercurial Ooze",
		[41175] = "Frostmane Scout",
		[32180] = "Carrionbasher",
		[6011] = "Felguard Sentry",
		[38817] = "Cat",
		[44372] = "Avalanchion",
		[43430] = "Stonecore Berserker",
		[3527] = "Healing Stream Totem <Totemica>",
		[43349] = "Marrowleaper",
		[16947] = "Gan'arg Servant",
		[12941] = "sosa",
		[46202] = "Dark Assassin",
		[32935] = "Young Wolf",
		[44220] = "Jade Rager",
		[79] = "Narg the Taskmaster",
		[8769] = "Wolf",
		[44316] = "Desiccated Spearman",
		[23177] = "Cilamila",
		[6071] = "Shaamon",
		[18130] = "Marshfang Ripper",
		[22138] = "Toche",
		[40120] = "Bruudon <Believeme>",
		[50318] = "Xorothian Satyr",
		[47609] = "Horde Rogue Infantry",
		[13229] = "thugtwo",
		[10814] = "Nachos",
		[20416] = "Pebblekeeper",
		[25419] = "Boiling Spirit",
		[14466] = "Horde Battle Standard <Hatepoem>",
		[40] = "Kobold Miner",
		[45787] = "Bloodeye Brute",
		[7049] = "Water Elemental",
		[40123] = "Twilight Overseer",
		[3579] = "Stoneclaw Totem <Xcite>",
		[31669] = "Water Elemental",
		[2560] = "Highland Thrasher",
		[6143] = "Wolf",
		[44988] = "Greater Quicksilver Ooze",
		[19457] = "Grillok \"Darkeye\"",
		[6243] = "Gelihast",
		[47130] = "Crazed Guard",
		[13341] = "Cat",
		[41253] = "Oath-Chained Infernal",
		[47226] = "Obsidian Stoneslave",
		[9273] = "Kyudo",
		[11919] = "Monkey <Missfelching>",
		[15427] = "Phuuzun <Sarue>",
		[12366] = "Monkey",
		[11879] = "Monkey",
		[38211] = "Cat",
		[33128] = "Young Cat",
		[20445] = "Mal'druk the Soulrender",
		[45618] = "Twilight Flamequencher",
		[37058] = "Cat",
		[1420] = "Young Cat <Zanhu>",
		[47610] = "Horde Shaman Infantry",
		[8346] = "Water Elemental",
		[6227] = "Mechano-Frostwalker",
		[11280] = "Wolf",
		[10856] = "Heswena",
		[16719] = "One",
		[13501] = "Monkey",
		[22910] = "Water Elemental",
		[4205] = "Water Elemental",
		[8410] = "Monkey <Dikylya>",
		[29096] = "Anub'ar Champion",
		[32181] = "Young Boar",
		[19921] = "Viper",
		[13986] = "Jhuuthun <Razzlock>",
		[9886] = "Shaaroon",
		[2630] = "Earthbind Totem <Totemica>",
		[47994] = "Blood of Iso'rath",
		[12566] = "Water Elemental",
		[16867] = "Shattered Hand Grunt",
		[11908] = "Bad Manner <Missfelching>",
		[27210] = "Keanoreevez <Keanoreevez>",
		[26455] = "Moonrest Highborne",
		[32101] = "Flaaroon",
		[38913] = "Twilight Vanquisher",
		[47642] = "Rustberg Fisherman",
		[8538] = "Unseen Servant",
		[21168] = "Nlgger",
		[1998] = "Webwood Lurker",
		[32453] = "Monkey",
		[40354] = "Water Elemental <Jfkpan>",
		[12902] = "Lorgus Jett",
		[28409] = "Zytax",
		[7765] = "Stonegobbler",
		[35367] = "Earthravager",
		[30935] = "Monke",
		[27062] = "Wolf",
		[40087] = "ONE",
		[46748] = "Stonard Kodo Beast",
		[31590] = "Scorpid",
		[23422] = "Biebie <Biebie>",
		[2026] = "Young Boar",
		[4887] = "Ghamoo-ra",
		[19378] = "Pryygrym",
		[6007] = "Shadowsworn Enforcer",
		[10736] = "Bonebasher",
		[39843] = "Twilight Stormcaller",
		[17824] = "Young Wolf <Gungunsntchg>",
		[10968] = "Wolf",
		[39939] = "Raging Firestorm",
		[6415] = "Thoodhun",
		[2588] = "Syndicate Prowler",
		[28729] = "Watcher Narjil",
		[45182] = "Blackscale Seacaller",
		[45084] = "Elemental Overseer",
		[41154] = "Batripper <Sleepgodx>",
		[10776] = "Fieola",
		[12062] = "Wolf",
		[29097] = "Anub'ar Crypt Fiend",
		[7474] = "Water Elemental <Buenarda>",
		[22719] = "ONE",
		[16871] = "Bleeding Hollow Grunt",
		[46493] = "Warlord Halthar",
		[43456] = "Troggzor the Earthinator",
		[28921] = "Hadronox",
		[41474] = "Monkey",
		[47287] = "Captain P. Harris",
		[17280] = "noope",
		[6487] = "Arcanist Doan",
		[6885] = "Wraadym",
		[42676] = "Amaury",
		[16757] = "Stonegnaw <Noned>",
		[44218] = "Sundered Emerald Colossus",
		[16789] = "Monkey <Fakeprada>",
		[18851] = "Spider",
		[17844] = "one",
		[50321] = "Xorothian Imp",
		[22991] = "bobools",
		[40867] = "Silithid",
		[39445] = "Lycanthoth Vandal",
		[47069] = "Totem of Tranquil Mind <Pumpingit>",
		[19668] = "Shadowfiend <Outlandish>",
		[44562] = "Opengut Behemoth",
		[1972] = "RapperRaptor <Tandroxin>",
		[14117] = "One",
		[45183] = "Ophelia",
		[44318] = "Rattlegore",
		[89] = "Infernal <Lobonegro>",
		[22144] = "Gordunni Elementalist",
		[12111] = "Pryydhon",
		[33181] = "Young Raptor",
		[34065] = "one <Fufurufa>",
		[46416] = "Twilight Skyterror",
		[18132] = "Umbraglow Stinger",
		[38361] = "Monkey",
		[5806] = "Drusona",
		[42228] = "Okril'lon Scout",
		[50320] = "Lost Ravager",
		[20258] = "Water Elemental",
		[3819] = "Young Raptor",
		[21313] = "ONE",
		[5719] = "Stonecruncher",
		[20669] = "KINKON",
		[10201] = "Plagueripper",
		[17285] = "Water Elemental",
		[8487] = "Monkey",
		[47901] = "Demon Containment Unit",
		[35550] = "BB",
		[35786] = "maikatidve <Ratflusher>",
		[38363] = "Monkey <Rotibilamana>",
		[16894] = "Cat",
		[43954] = "Fungal Terror",
		[27723] = "Water Elemental",
		[10257] = "Water Elemental",
		[7800] = "Mekgineer Thermaplugg",
		[42244] = "Drowned Gilnean Merchant",
		[28730] = "Watcher Gashra",
		[14381] = "en <Date>",
		[8415] = "Monkey <Dikylya>",
		[46648] = "Foreman Wellson",
		[43234] = "Stone Trogg Geomancer",
		[34059] = "two <Fufurufa>",
		[40229] = "Scalding Rock Elemental",
		[22704] = "NIGG",
		[32455] = "Monkey <Bopmeow>",
		[26828] = "Monkey",
		[44449] = "Deathguard War-Captain",
		[47550] = "Imprisoned Worker",
		[28922] = "Anub'ar Crusher",
		[4813] = "Twilight Shadowmage",
		[5844] = "two",
		[39844] = "Howling Riftdweller",
		[45664] = "Landlocked Grouper",
		[45179] = "Blackscale Myrmidon",
		[26605] = "Anub'ar Underlord",
		[4805] = "Blackfathom Sea Witch",
		[25981] = "Scourged Footman",
		[2149] = "Young Wolf",
		[35322] = "Freeze",
		[46911] = "Lava Surger",
		[18079] = "Umbrafen Seer",
		[25038] = "Monkey",
		[45984] = "Blackscale Raider",
		[41924] = "Dark Iron Invader",
		[24063] = "Water Elemental",
		[26125] = "Risen Ally <Necrolord>",
		[39974] = "Twilight Inferno Lord",
		[24111] = "Brainthief",
		[8491] = "Rotravager",
		[45185] = "Diamond-Blade Shredder",
		[21423] = "Gore-Scythe Ravager",
		[40134] = "Nightmare Terror",
		[20099] = "Deux <Lvz>",
		[24207] = "Army of the Dead Ghoul <Aeglos>",
		[47391] = "Highland Black Drake",
		[9570] = "Khuuzhum",
		[22209] = "eleGanCo",
		[7866] = "Pebblegnaw <Denathrius>",
		[43427] = "Furious Hyjal Warden",
		[33229] = "Graizer",
		[4809] = "Twilight Acolyte",
		[5836] = "one",
		[18213] = "Mire Hydra",
		[40518] = "Water Elemental",
		[4825] = "Aku'mai Snapjaw",
		[4829] = "Aku'mai",
		[48798] = "Devouring Flames",
		[44323] = "Darkmaster Gandling",
		[12999] = "World Invisible Trigger",
		[24463] = "SHEY <Yonkihunter>",
		[29594] = "Monkey <Scrappyhunt>",
		[39846] = "Leyden Copperkleist",
		[46944] = "Hurp'derp",
		[40838] = "Dark Iron Laborer",
		[45985] = "Blackscale Mistress",
		[5892] = "zacfail",
		[50319] = "Dimensional Ooze",
		[44035] = "Fungal Monstrosity",
		[31603] = "maikati",
		[17462] = "Artillery",
		[28731] = "Watcher Silthik",
		[27164] = "Spirit Beast",
		[40103] = "THREE <Badname>",
		[51166] = "Hellscream's Sentry",
		[32226] = "Spider",
		[18853] = "Sunfury Bloodwarder",
		[41254] = "Enthralled Cultist",
		[33248] = "Power Word: Barrier",
		[16583] = "Monkey <Jesse>",
		[2976] = "Vilriel",
		[8532] = "Diseased Flayer",
		[47552] = "Exiled Mage",
		[29335] = "Anub'ar Webspinner",
		[41478] = "Snow Tracker Wolf",
		[22461] = "Fel Cannon MKI",
		[14548] = "Crab",
		[5976] = "Dreadmaul Brute",
		[45175] = "Axebite Marine",
		[5984] = "Ciucas <Jon>",
		[5988] = "Scorpok Stinger",
		[94] = "Cutpurse",
		[42757] = "Slain Crew Member's Spirit",
		[34605] = "kirnon",
		[7027] = "Kali",
		[46945] = "Torg Drakeflayer",
		[42885] = "Twilight Saboteur",
		[42917] = "Twilight Duskwarden",
		[1922] = "Gray Forest Wolf",
		[45241] = "Forsaken Trooper",
		[8595] = "Shaatom",
		[18981] = "Doomwhisperer",
		[32296] = "Stinkmeaner",
		[46167] = "Stephen Browman",
		[43065] = "Monkey",
		[40104] = "Water Elemental",
		[21401] = "Earthchewer",
		[43237] = "Deadly Crystalgazer",
		[17846] = "two <Braindeadly>",
		[13303] = "Kreephom",
		[12416] = "Water Elemental",
		[39273] = "pachote",
		[9075] = "Tombslicer",
		[41312] = "Cat",
		[14206] = "KRUSHER",
		[11329] = "Ormlos",
		[38486] = "Cat",
		[47649] = "Wild Mushroom <Ovl>",
		[12192] = "Monkey <Oirbith>",
		[8296] = "Mojo the Twisted",
		[43537] = "Stonecore Earthshaper",
		[6112] = "Windfury Totem <Xcite>",
		[22754] = "Monkey",
		[47768] = "Glopgut Hurler",
		[15309] = "Disola <Sarue>",
		[18694] = "Collidus the Warp-Watcher",
		[3581] = "Sewer Beast",
		[19397] = "Mo'arg Overseer",
		[22482] = "Monkey <Boula>",
		[45987] = "Dragonmaw Defender",
		[11265] = "Gitanas",
		[27645] = "Cat",
		[28684] = "Krik'thir the Gatewatcher",
		[43258] = "Lodestone Elemental",
		[19536] = "Zhaahon",
		[45156] = "Shadril",
		[46166] = "Stonard Warrior",
		[33967] = "Jhuughun",
		[7203] = "Monkey",
		[7207] = "Monkey <Bowstyle>",
		[9555] = "Jhuuzhem",
		[10330] = "Flaathun",
		[31913] = "Malpariditax <Fufurufa>",
		[25806] = "Loot Crazed Poacher",
		[1547] = "Decrepit Darkhound",
		[46499] = "Guardian of Ancient Kings <Kicibomba>",
		[6212] = "Dark Iron Agent",
		[49632] = "Wildhammer Raider",
		[47277] = "Angered Spirit",
		[6224] = "Leprous Machinesmith",
		[35406] = "Haagzun",
		[6232] = "Arcane Nullifier X-21",
		[5535] = "Water Elemental <Rinsemachine>",
		[27742] = "Monkey",
		[47181] = "Overlook Spirit",
		[2103] = "Water Elemental <Copium>",
		[46851] = "Dragonmaw Straggler",
		[28733] = "Anub'ar Shadowcaster",
		[42823] = "Twilight Priestess",
		[46947] = "Cadaver Collage",
		[40841] = "Searing Guardian",
		[44326] = "Andorhal Deathguard",
		[44815] = "Warped Cultist",
		[19190] = "Fel Handler",
		[40883] = "Skywall Denizen",
		[10522] = "Water Elemental",
		[29098] = "Anub'ar Necromancer",
		[5607] = "Water Elemental",
		[7323] = "Monkey",
		[25184] = "Water Elemental",
		[15072] = "Ratgnaw",
		[99] = "Morgaine the Sly",
		[42248] = "Drowned Gilnean Sailor",
		[18087] = "Darkcrest Siren",
		[8548] = "Vile Tutor",
		[44847] = "Twilight Armsman",
		[45838] = "Twilight Ettin",
		[3573] = "Mana Spring Totem <Tiko>",
		[34256] = "Spider",
		[42696] = "Stonecore Warbringer",
		[6004] = "Shadowsworn Cultist",
		[39627] = "Spider",
		[12704] = "Pebbleflayer",
		[47724] = "Twilight Windwarper",
		[19398] = "Gan'arg Peon",
		[8531] = "Gibbering Ghoul",
		[33489] = "Young Raptor",
		[4380] = "pidarasniger",
		[39436] = "Twilight Proveditor",
		[34608] = "Monkey <Hateswedes>",
		[26831] = "Keanoreevez <Keanoreevez>",
		[46948] = "Lord Geoffery Tulvan",
		[2215] = "Water Elemental",
		[45989] = "Goblin Bombardier",
		[16950] = "Netherhound",
		[7431] = "Frostsaber",
		[4411] = "Koda",
		[46579] = "Depths Overseer",
		[17464] = "Muk <Vulkanikq>",
		[42089] = "Water Elemental",
		[41565] = "Molten Tormentor",
		[40107] = "Thol'embaar",
		[6436] = "Monkey <Satsumaqt>",
		[48355] = "Hellscream Guard",
		[42249] = "Drowned Gilnean Settler",
		[11859] = "Doomguard <Athene>",
		[13398] = "Glyaith",
		[18978] = "Heckling Fel Sprite",
		[29900] = "Monkey",
		[19686] = "Nether Anomaly",
		[19702] = "Seggszag <Anci>",
		[37358] = "Water Elemental",
		[46597] = "Skeletal Beastmaster",
		[6433] = "Hammercatcher",
		[6429] = "Monkey",
		[39028] = "Tangerine",
		[46157] = "Aura of Foreboding",
		[30128] = "AdolphNigler",
		[26643] = "Rabid Grizzly",
		[29117] = "Anub'ar Champion",
		[16873] = "Bleeding Hollow Dark Shaman",
		[39724] = "Horrorguard",
		[39756] = "The Manipulator",
		[46949] = "Emberscar the Devourer",
		[4482] = "Cat",
		[48036] = "Warden Silva",
		[24773] = "Gelkol",
		[31227] = "Young Boar",
		[0] = "[*] Vineyard Fire",
		[29213] = "Anub'ar Darter",
		[47607] = "Horde Druid Infantry",
		[20038] = "Ratgrinder",
		[4510] = "Cat",
		[46310] = "Dragonmaw Marauder",
		[4518] = "Czolgista",
		[48356] = "Karosh",
		[41227] = "Jesco <Jesco>",
		[47244] = "Mirror Image <Dtor>",
		[7603] = "Leprous Assistant",
		[18120] = "Ango'rosh Mauler",
		[18136] = "Marsh Lurker",
		[47525] = "Servant of Lord Geoffery <Lord Geoffery Tulvan>",
		[1852] = "Araj the Summoner",
		[49629] = "Krazzworks Defender",
		[39437] = "Twilight Hunter",
		[46630] = "Accursed Longshoreman",
		[33529] = "Phuudym",
		[21317] = "TWO <Seyren>",
		[9180] = "Marrowchomp",
		[18280] = "Sporewing",
		[7663] = "Jhuuthun",
		[44936] = "Murkstone Trogg",
		[44808] = "Twilight Striker",
		[34610] = "Xurupita",
		[15438] = "Greater Fire Elemental",
		[19399] = "Fel Cannon",
		[40844] = "Cindermaul",
		[21477] = "Rocknail Flayer",
		[11266] = "Marrowravager",
		[10331] = "Batstalker",
		[38926] = "Twilight Flamecaller",
		[33273] = "Young Boar <Antipov>",
		[29917] = "Monkey <Gungunsntchg>",
		[7703] = "DDShlongLegs",
		[2321] = "Water Elemental",
		[15414] = "Monkey <Intuitionist>",
		[41164] = "Jarroc Torn-Wing",
		[48357] = "Hellscream's Reach Recruit",
		[34067] = "trece <Fufurufa>",
		[44329] = "Stickbone Berserker",
		[48453] = "Irontree Chopper",
		[4291] = "Scarlet Diviner",
		[20742] = "two <Grusela>",
		[48549] = "Pool of Lava",
		[29933] = "Cat",
		[47590] = "Ghastly Convict",
		[39438] = "Twilight Slavedriver",
		[4726] = "Cat",
		[38479] = "Sarvina",
		[44649] = "Twilight Centurion",
		[29182] = "Drooshon",
		[45257] = "Mordak Nightbender",
		[20103] = "Trois <Lvz>",
		[46823] = "Restless Infantry",
		[43499] = "Consecration",
		[4810] = "Twilight Reaver",
		[10467] = "Mana Tide Totem <Elclassico>",
		[40813] = "Riddickk <Yhinowuan>",
		[40845] = "Forgemaster Pyrendius",
		[2371] = "Helkrast",
		[4814] = "Twilight Elementalist",
		[18952] = "Bonechewer Scavenger",
		[29264] = "Spirit Wolf <Xcite>",
		[426] = "Young Wolf",
		[17306] = "Spider",
		[46153] = "Highland Worg",
		[28239] = "Water Elemental",
		[19400] = "Fel Reaver Sentry",
		[41165] = "Shahandana",
		[8525] = "Scourge Warder",
		[15694] = "Monkey <Intuitionist>",
		[8541] = "Hate Shrieker",
		[5913] = "Tremor Totem <Viberly>",
		[14695] = "AdolphNigler <Papichulo>",
		[4798] = "Fallenroot Shadowstalker",
		[31452] = "Young Cat <Bloubi>",
		[23284] = "Young Mastiff <Murderouz>",
		[47591] = "Baradin Crocolisk",
		[8597] = "Bonestealer",
		[4818] = "Blindlight Murloc",
		[2435] = "Water Elemental <Mntr>",
		[41581] = "Child of Tortolla",
		[43659] = "Water Elemental",
		[18281] = "Boglash",
		[2439] = "Major Samuelson",
		[5925] = "Grounding Totem <Popthebob>",
		[7915] = "Walking Bomb",
		[5873] = "Stoneskin Totem <Kollegs>",
		[25650] = "Plagued Scavenger",
		[40814] = "Azralon the Gatekeeper",
		[32886] = "Bheedhon",
		[21478] = "Rocknail Ripper",
		[47304] = "Commander Largo",
		[44011] = "Muddied Water Elemental",
		[2441] = "Graz'juk",
		[11898] = "Cat",
		[17466] = "Atrophy <Vulkanikq>",
		[45162] = "Hearthglen Trainee",
		[39344] = "Fiery Instructor",
		[44619] = "Twilight Binder",
		[35028] = "Marrowkeeper <Mortanius>",
		[7975] = "Jhuummon <Aramil>",
		[45322] = "Frostfire Orb",
		[44331] = "Andorhal Deathguard",
		[28017] = "Bloodworm",
		[8845] = "Earththief",
		[45450] = "The Lone Hunter",
		[10875] = "Luvcho",
		[41902] = "Dark Iron Pyromancer",
		[46569] = "Forgotten Ghoul",
		[42607] = "Rockslice Ripper",
		[8015] = "You",
		[3500] = "Nalloz",
		[5977] = "Dreadmaul Mauler",
		[31053] = "One",
		[5985] = "Snickerfang Hyena",
		[8035] = "Dark Iron Land Mine <Dark Iron Agent>",
		[46825] = "Restless Soldier",
		[20792] = "Bloodscale Elemental <Rajis Fyashe>",
		[4978] = "Aku'mai Servant",
		[4982] = "Rhuuzun <Foxton>",
		[29119] = "Anub'ar Necromancer",
		[27217] = "Keanoreevez",
		[42925] = "Ravenous Tunneler",
		[40911] = "Khiigrym <Weedlewee>",
		[16907] = "Bleeding Hollow Peon",
		[30222] = "Bad Manner <Damo>",
		[45099] = "Magmatooth",
		[16174] = "Mezzkrit",
		[19017] = "Catola <Pronto>",
		[40080] = "Unbound Flame Spirit",
		[46571] = "First Lieutenant Connor",
		[20088] = "Bloodscale Overseer",
		[7236] = "Drusriana",
		[46507] = "Darkwood Broodmother",
		[2523] = "Searing Totem <Detherox>",
		[47593] = "Problim",
		[18122] = "Dreghood Drudge",
		[18138] = "Umbrafen Eel",
		[46506] = "Guardian of Ancient Kings <Perfomance>",
		[47561] = "Warden Guard",
		[46570] = "Putrid Worg",
		[21319] = "TRE <Seyren>",
		[47657] = "Suspicious Villager",
		[1783] = "Skeletal Flayer",
		[1784] = "Skeletal Sorcerer",
		[24372] = "retyla <Trapstars>",
		[18282] = "Lord Klaq",
		[27073] = "Young Raptor <Attq>",
		[13257] = "hujoza",
		[13505] = "Monkey <Kfc>",
		[40336] = "Charbringer",
		[7172] = "Brainbreaker",
		[46954] = "Shadowy Apparition <Betispageti>",
		[43917] = "Rock Borer",
		[40880] = "Firelands Denizen",
		[32748] = "Water Elemental",
		[6233] = "Mechanized Sentry",
		[7100] = "Warpwood Moss Flayer",
		[42031] = "Water Elemental",
		[8222] = "Cat",
		[26658] = "Reckless Scavenger",
		[42606] = "Rockslice Flayer",
		[46328] = "Enslaved Tempest",
		[27761] = "Water Elemental",
		[48361] = "Private Sarlosk",
		[15439] = "Fire Elemental Totem <Nvd>",
		[15447] = "Wrath of Air Totem <Pumpingit>",
		[2599] = "Otto",
		[2591] = "Syndicate Magus",
		[18650] = "Water Elemental",
		[43438] = "Corborus",
		[2597] = "Lord Falconcrest",
		[12426] = "Spirit Beast",
		[32013] = "Spider <Hypertiago>",
		[6225] = "Mechano-Tank",
		[6229] = "Crowd Pummeler 9-60",
		[40561] = "Deep Corruptor",
		[43662] = "Unbound Earth Rager",
		[6005] = "Shadowsworn Thug",
		[19833] = "Venomous Snake",
		[3638] = "Flaaroon",
		[40783] = "Dirtai <Tearzfears>",
		[2619] = "Flaaghun <Astolfo>",
		[13537] = "Monkey <Kfc>",
		[29120] = "Anub'arak",
		[42895] = "Tornado <Howling Riftdweller>",
		[8446] = "hopeshedies <Fakeprada>",
		[38896] = "Blazebound Elemental",
		[36853] = "Zhaatom",
		[14608] = "moa",
		[29216] = "Anub'ar Guardian",
		[40018] = "Water Elemental",
		[7320] = "parashnik",
		[24149] = "Carrioncruncher",
		[41166] = "Gomegaz",
		[42924] = "Twilight Laborer",
		[8526] = "Dark Caster",
		[18137] = "Marsh Dredger",
		[18121] = "Ango'rosh Souleater",
		[50312] = "Mana-Compelled Shade",
		[29582] = "Water Elemental",
		[32461] = "Raptor",
		[47531] = "Captive Spirit",
		[46508] = "Darkwood Lurker",
		[4299] = "Scarlet Chaplain",
		[47627] = "Rustberg Bandit",
		[47659] = "Apprehensive Worker",
		[28734] = "Anub'ar Skirmisher",
		[44462] = "Jearl Donald",
		[29853] = "Ratcruncher",
		[29064] = "Anub'ar Necromancer",
		[31598] = "Young Dragonhawk",
		[116] = "Bandit",
		[44814] = "Crazed Cultist",
		[23462] = "Monkey",
		[17468] = "Shah <Vulkanikq>",
		[5410] = "Wolf",
		[19418] = "Cat",
		[19434] = "Dreadcaller",
		[44967] = "Maziel",
		[2209] = "Water Elemental",
		[25620] = "Thokgron <Kimil>",
		[44079] = "Agate Mancrusher",
		[2701] = "Kittypurry",
		[45166] = "Withdrawn Soul",
		[50313] = "Displaced Warp Stalker",
		[41138] = "Okril'lon Defender",
		[40147] = "Baron Geddon",
		[48363] = "Captain Prug",
		[10836] = "Cat <Simea>",
		[45358] = "Bound Fleshburner",
		[41086] = "Brainravager",
		[6457] = "Monkey <Satsumaqt>",
		[13967] = "Alien <Oldmemories>",
		[39348] = "Smolderos the Carbonizer",
		[40403] = "Spinescale Matriarch",
		[11915] = "Monkey <Missfelching>",
		[46605] = "Shipwrecked Sailor",
		[14731] = "Tombgnaw",
		[7455] = "Echeyakee",
		[16717] = "Two <Biz>",
		[15761] = "Rootravager",
		[42673] = "Monkey <Cours>",
		[46643] = "Accursed Shipbuilder",
		[118] = "Prowler",
		[9941] = "Carriongobbler",
		[42801] = "Mor'norokk the Hateful",
		[44879] = "Ogre Bodyguard",
		[10988] = "Dashy",
		[46989] = "Crazed Soldier",
		[43952] = "Earthen Catapult",
		[16791] = "Monkey <Fakeprada>",
		[7673] = "Madarao",
		[7166] = "Haaghun <Gosc>",
		[29217] = "Anub'ar Venomancer",
		[50250] = "Ice Avatar",
		[44835] = "Haethen Kaul",
		[20115] = "Umbrafen Witchdoctor",
		[475] = "Kobold Tunneler",
		[18044] = "Rajis Fyashe",
		[13558] = "Wheelwithdog <Hela>",
		[9867] = "Monkey <Qlipoth>",
		[476] = "Kobold Geomancer",
		[27315] = "Khiinam",
		[18340] = "Steam Pump Overseer",
		[29756] = "Young Wolf",
		[43228] = "Stone Trogg Berserker",
		[2789] = "Water Elemental",
		[29153] = "Animated Bones <Anub'ar Necromancer>",
		[5582] = "yunglean",
		[478] = "Riverpaw Outrunner",
		[32558] = "Hyena",
		[8304] = "Dreadscorn",
		[9142] = "Water Elemental",
		[30] = "Forest Spider",
		[525] = "Mangy Wolf",
		[13965] = "Chikinuggies",
		[34586] = "Young Wolf",
		[1918] = "Ruirin",
		[19387] = "Monkey <Boula>",
		[43960] = "Stone Trogg Reinforcement",
		[9206] = "Helnia",
		[15352] = "Greater Earth Elemental <Amerish>",
		[9222] = "Water Elemental",
		[6665] = "Young Raptor",
		[43026] = "Deepstone Elemental",
		[29128] = "Anub'ar Prime Guard",
		[47182] = "Overlook Spectre",
		[19946] = "Darkcrest Slaver",
		[5229] = "Wraadrom",
		[5666] = "Wormdrinker <Bo>",
		[43218] = "Twilight Bloodshaper",
		[43250] = "Needlerock Rider",
		[6302] = "Raptor",
		[34926] = "Casketflayer",
		[31919] = "Young Wolf",
		[43134] = "Stone Trogg Ambusher",
		[8520] = "Plague Ravager",
		[47534] = "Cellblock Ooze",
		[14465] = "Alliance Battle Standard <Duality>",
		[11404] = "Raptor <Monkeydo>",
		[39446] = "Lycanthoth",
		[45616] = "Twilight Abductor",
		[23229] = "Agatson",
		[4815] = "Murkshallow Snapclaw",
		[6867] = "Tracking Hound",
		[48628] = "Ferocious Yeti",
		[38951] = "Twilight Assassin",
		[6875] = "Eyethief",
		[4719] = "Water Elemental",
		[44849] = "Twilight Crusher",
		[31029] = "michi <Anitas>",
		[5754] = "Khiinem",
		[3128] = "Cat",
		[19947] = "Darkcrest Sorceress",
		[31216] = "Mirror Image <Zushin>",
		[39926] = "Twilight Inciter",
		[45243] = "Forsaken Trooper",
		[43059] = "Monkey <Kuroisshi>",
		[47183] = "Ghastly Worker",
		[43123] = "Living Blood",
		[50316] = "K'areshi Trader",
		[47447] = "Keep Lord Farson",
		[43391] = "Millhouse Manastorm",
		[1964] = "Treant <Kijimoshi>",
		[18077] = "Umbrafen Oracle",
		[8543] = "Stitched Horror",
		[8551] = "Dark Summoner",
		[18125] = "Starving Fungal Giant",
		[4799] = "Fallenroot Hellcaller",
		[23553] = "Raptor",
		[4807] = "Blackfathom Myrmidon",
		[4811] = "Twilight Aquamancer",
		[46608] = "Tank",
		[4819] = "Blindlight Muckdweller",
		[4823] = "Barbed Crustacean",
		[35401] = "Kehlouch",
		[4831] = "Lady Sarevess",
		[5858] = "Greater Lava Spider",
		[5862] = "Wolf",
		[3757] = "Droodhun",
		[40884] = "Deepholm Denizen",
		[5874] = "Strength of Earth Totem <Nvd>",
		[19261] = "Infernal Warbringer",
		[49006] = "Skyshredder Crewmember",
		[4969] = "Biztuk",
		[7530] = "Oogabooga",
		[4977] = "Murkshallow Softshell",
		[2951] = "Water Elemental",
		[47120] = "Argaloth",
		[18477] = "Timber Worg Alpha",
		[47184] = "Stone Trogg Fungalmancer",
		[14557] = "WOLFANKILLER",
		[50317] = "Mana Thirster",
		[40119] = "Gzaafenn",
		[32755] = "Selriana <Gimmepi>",
		[6047] = "Aqua Guardian",
		[2910] = "Water Elemental",
		[7984] = "Young Tallstrider",
		[41302] = "Stonemuncher",
		[40089] = "TWO <Badname>",
		[5950] = "Flametongue Totem <Cristine>",
		[44816] = "The Black Bishop",
		[48591] = "Poison Cloud",
		[20747] = "three <Grusela>",
		[33310] = "Water Elemental <Sharkoum>",
		[46641] = "Ghastly Dockhand",
		[5974] = "Dreadmaul Ogre",
		[5978] = "Dreadmaul Warlock",
		[15524] = "Wolf",
		[32096] = "Shaaghun",
		[5990] = "Redstone Basilisk",
		[28732] = "Anub'ar Warrior",
		[17011] = "Scorpid <Vanahimm>",
		[45239] = "Lesser Val'kyr",
		[6006] = "Shadowsworn Adept",
		[6010] = "Felhound",
		[48016] = "Unbound Emberfiend",
		[16879] = "Starving Helboar",
		[29171] = "costica",
		[31233] = "Sinewy Wolf",
		[1441] = "Young Raptor",
		[21419] = "Infernal Attacker",
		[5760] = "Monkey <Crackerjoe>",
		[4593] = "Kragtaz",
		[22106] = "Ruul's Netherdrake",
		[45235] = "Aradne",
		[18046] = "Rajah Haghazed",
		[46322] = "Shaman of the Black",
		[182] = "Abatal",
		[1195] = "Forest Lurker",
		[45395] = "Faceless Soulclaimer",
		[23241] = "Monkey <Damo>",
		[39646] = "Gar'gol",
		[47537] = "Archmage Galus",
		[25628] = "Young Wolf",
		[46578] = "Twilight Miner",
		[46586] = "Wandering Soul",
	},
	["death_recap"] = {
		["enabled"] = true,
		["show_segments"] = false,
		["show_life_percent"] = false,
		["relevance_time"] = 7,
	},
	["spell_pool"] = {
		4, -- [1]
		8, -- [2]
		"Environment (Falling)", -- [3]
		[61258] = 6,
		[1535] = 7,
		[79881] = 1,
		[8222] = 6,
		[1543] = 3,
		[88453] = 3,
		[86662] = 1,
		[53646] = 9,
		[47633] = 6,
		[8382] = "Blindlight Muckdweller",
		[31117] = 9,
		[77451] = 7,
		[85767] = 9,
		[29166] = 10,
		[86663] = 1,
		[90885] = 9,
		[91141] = 10,
		[48721] = 6,
		[85256] = 2,
		[85384] = 1,
		[21394] = 3,
		[31661] = 8,
		[10733] = "Mechano-Flamewalker",
		[31789] = 2,
		[31821] = 2,
		[403] = 7,
		[84617] = 4,
		[55694] = 1,
		[57933] = 4,
		[19891] = 2,
		[48018] = 9,
		[79884] = "Horde Shaman Infantry",
		[48210] = 9,
		[6552] = 1,
		[90887] = 2,
		[20243] = 1,
		[50769] = 10,
		[85386] = 1,
		[93830] = 5,
		[6648] = 3,
		[55503] = 1,
		[84619] = 1,
		[45524] = "Aeglos",
		[421] = 7,
		[87178] = 5,
		[87562] = 9,
		[9438] = "Arcanist Doan",
		[79886] = "Horde Shaman Infantry",
		[19028] = 9,
		[3409] = 4,
		[80398] = 9,
		[84620] = 1,
		[23250] = 1,
		[1715] = 1,
		[430] = 5,
		[85388] = 1,
		[431] = 5,
		[34650] = "Shadowfiend <Outlandish>",
		[44949] = 1,
		[83853] = 8,
		[96263] = 2,
		[23602] = 1,
		[94472] = 5,
		[23698] = 5,
		[66198] = 6,
		[35290] = "Young Boar <Coolaboy>",
		[51730] = 7,
		[438] = 8,
		[35546] = 4,
		[439] = 1,
		[17877] = 9,
		[28176] = "Yuke",
		[50259] = 10,
		[20052] = 2,
		[86669] = 2,
		[91019] = 8,
		[91147] = 5,
		[79633] = 3,
		[59343] = "Anub'ar Champion",
		[96265] = 6,
		[98440] = "Szopka",
		[35099] = 3,
		[28880] = 1,
		[5185] = 10,
		[453] = 5,
		[5209] = 10,
		[89485] = 5,
		[8399] = "Twilight Lord Kelris",
		[79634] = 6,
		[16886] = 10,
		[79890] = "Horde Shaman Infantry",
		[31279] = "Drowned Gilnean Settler",
		[458] = 5,
		[1833] = 4,
		[23219] = 10,
		[74517] = 2,
		[93068] = 4,
		[91149] = 10,
		[7384] = 1,
		[21396] = 2,
		[10734] = "Mechano-Frostwalker",
		[59344] = "Anub'ar Champion",
		[465] = 2,
		[17462] = 5,
		[467] = 10,
		[25810] = 3,
		[469] = 1,
		[97547] = 10,
		[472] = 1,
		[32239] = 2,
		[92174] = 10,
		[20053] = 2,
		[80265] = 7,
		[475] = 8,
		[84626] = 2,
		[24275] = 2,
		[88972] = "Argaloth",
		[7328] = 2,
		[87173] = 2,
		[66843] = 7,
		[91139] = 2,
		[79124] = 2,
		[63311] = 9,
		[63375] = 7,
		[64904] = 5,
		[51753] = 3,
		[87840] = 3,
		[5697] = 9,
		[25780] = 2,
		[35101] = 3,
		[84627] = 2,
		[90896] = 8,
		[7744] = 4,
		[32750] = "Dark Iron Pyromancer",
		[79880] = 8,
		[1943] = 4,
		[81301] = "Slayhorde",
		[772] = 1,
		[1949] = 9,
		[79638] = 1,
		[1953] = 8,
		[60433] = 10,
		[85768] = 9,
		[92432] = 2,
		[88466] = 3,
		[95872] = 10,
		[62800] = "Young Boar",
		[23252] = 4,
		[87556] = 1,
		[95874] = 6,
		[17207] = 1,
		[42650] = 6,
		[5857] = 9,
		[77478] = 7,
		[92052] = 4,
		[47000] = 8,
		[59914] = 10,
		[25747] = 4,
		[17463] = 8,
		[498] = 2,
		[82326] = 2,
		[29841] = 1,
		[17619] = 10,
		[90898] = 9,
		[45529] = 6,
		[66844] = 7,
		[87188] = 2,
		[8024] = 7,
		[51470] = 7,
		[87717] = 7,
		[47960] = 9,
		[8056] = 7,
		[32240] = 4,
		[8072] = 7,
		[370] = 7,
		[63560] = 6,
		[82327] = 2,
		[79639] = 10,
		[62801] = "yes <Veganpets>",
		[16236] = 7,
		[30449] = 8,
		[60946] = 9,
		[87189] = 2,
		[66847] = 10,
		[879] = 2,
		[7927] = 4,
		[34655] = 3,
		[8184] = 7,
		[59347] = "Anub'ar Crypt Fiend",
		[92179] = 2,
		[47193] = 9,
		[53398] = 3,
		[84375] = 2,
		[72221] = 5,
		[86678] = 2,
		[90900] = 7,
		[23697] = 5,
		[56160] = 5,
		[57940] = 2,
		[2094] = 4,
		[2098] = 4,
		[47897] = 9,
		[527] = 5,
		[16856] = 1,
		[73629] = 2,
		[48153] = 5,
		[92184] = 6,
		[92436] = 1,
		[8512] = 7,
		[688] = "Tearzfears",
		[23221] = 3,
		[12654] = 8,
		[64977] = 8,
		[60947] = 9,
		[6353] = 9,
		[33110] = 5,
		[82949] = 3,
		[408] = "Holyundead",
		[543] = 8,
		[23509] = 6,
		[87959] = 5,
		[53271] = 3,
		[17464] = 8,
		[14893] = 5,
		[17528] = 1,
		[29842] = 1,
		[27827] = 5,
		[53655] = 2,
		[435] = 8,
		[21169] = 7,
		[83098] = 8,
		[79132] = 4,
		[23922] = 1,
		[1725] = 4,
		[23989] = 3,
		[33697] = 7,
		[94463] = 10,
		[9007] = 10,
		[80028] = "Rock Borer",
		[64658] = 3,
		[84378] = 2,
		[96268] = 6,
		[5760] = 4,
		[52109] = 7,
		[95870] = 5,
		[44572] = 8,
		[83619] = 8,
		[81170] = 10,
		[49806] = "Anub'ar Warrior",
		[77606] = 6,
		[91136] = 5,
		[605] = 5,
		[92055] = 4,
		[79901] = "Accursed Longshoreman",
		[6673] = 1,
		[580] = 8,
		[88473] = 10,
		[16595] = 2,
		[66188] = 6,
		[6713] = "Murkshallow Snapclaw",
		[585] = 5,
		[586] = 5,
		[87194] = 5,
		[588] = 5,
		[589] = 5,
		[66060] = 3,
		[91800] = "Batstalker",
		[6777] = 7,
		[6785] = 10,
		[79902] = "Accursed Longshoreman",
		[16953] = 10,
		[54424] = 9,
		[50271] = "Hyena",
		[90895] = 9,
		[13339] = 9,
		[54680] = "KRUSHER",
		[2139] = 8,
		[6201] = 9,
		[603] = 9,
		[50842] = 6,
		[77216] = "Dun Morogh Rifleman",
		[22812] = 10,
		[77472] = 7,
		[23510] = 10,
		[53209] = 3,
		[11791] = 4,
		[34914] = 5,
		[59542] = 2,
		[81574] = "Stonecore Berserker",
		[73510] = 5,
		[2458] = 1,
		[76577] = 4,
		[11196] = 1,
		[32018] = 10,
		[93337] = 4,
		[79136] = 4,
		[75170] = 8,
		[81439] = "Millhouse Manastorm",
		[91802] = "Carrionstalker <Epstein>",
		[16857] = 10,
		[33763] = 10,
		[676] = 1,
		[33891] = 10,
		[84994] = 1,
		[92043] = 4,
		[82691] = 8,
		[92826] = 8,
		[54428] = 2,
		[42463] = 2,
		[48020] = 9,
		[635] = 2,
		[79126] = 2,
		[83359] = 3,
		[81440] = "Millhouse Manastorm",
		[81568] = "Stonecore Berserker",
		[86273] = 2,
		[18425] = 4,
		[92187] = 6,
		[92315] = 8,
		[59543] = 3,
		[5570] = 10,
		[62606] = 10,
		[66216] = 6,
		[45470] = 6,
		[74522] = 3,
		[53148] = "Gitanas <Gitanus>",
		[93339] = 10,
		[80158] = "Stonecore Warbringer",
		[66846] = 1,
		[81441] = "Millhouse Manastorm",
		[81569] = "Stonecore Berserker",
		[25046] = 4,
		[783] = 10,
		[740] = 10,
		[60503] = 1,
		[7321] = 8,
		[42208] = 8,
		[75176] = 10,
		[23223] = 8,
		[59365] = "Watcher Narjil",
		[19574] = 3,
		[2894] = 7,
		[92166] = 2,
		[339] = 10,
		[97690] = 5,
		[81442] = "Millhouse Manastorm",
		[1459] = 8,
		[83745] = 9,
		[93828] = 8,
		[19505] = "Traaghun <Ivylab>",
		[5394] = 7,
		[59544] = "Docwho",
		[19577] = 1,
		[10832] = "Arcane Nullifier X-21",
		[53595] = 2,
		[88063] = 2,
		[11824] = "Twilight Elementalist",
		[24378] = 3,
		[93341] = 8,
		[19801] = 3,
		[97691] = 5,
		[686] = 9,
		[687] = 9,
		[83746] = 9,
		[689] = 9,
		[73899] = "Budala",
		[691] = 9,
		[87551] = 10,
		[693] = 9,
		[50461] = 6,
		[20153] = "Infernal <Morris>",
		[2782] = 10,
		[697] = "Kimil",
		[54986] = 2,
		[89342] = 5,
		[53467] = "Anub'arak",
		[95227] = 8,
		[702] = 9,
		[91807] = "Carrionstalker <Epstein>",
		[61336] = 10,
		[81828] = "[*] Thrashing Charge",
		[59417] = "Hadronox",
		[76691] = 2,
		[64901] = 5,
		[53468] = "Anub'arak",
		[710] = 9,
		[83468] = 1,
		[76583] = "Scarlet Monk",
		[74245] = 1,
		[82987] = 7,
		[91296] = 5,
		[66215] = 6,
		[5730] = 7,
		[85539] = 9,
		[16827] = "Doge <Exor>",
		[27094] = 4,
		[50589] = 9,
		[15357] = 5,
		[11264] = "Mechano-Frostwalker",
		[50334] = 10,
		[92576] = 1,
		[2818] = 4,
		[92832] = 6,
		[50590] = 9,
		[45902] = 6,
		[91644] = "Toche",
		[50782] = 1,
		[81281] = 10,
		[79106] = 5,
		[87587] = 7,
		[19386] = 3,
		[47008] = "Argaloth",
		[84169] = 2,
		[51723] = 4,
		[43680] = 1,
		[80167] = 5,
		[76201] = 2,
		[88611] = 4,
		[5176] = 10,
		[82726] = 3,
		[57819] = 1,
		[746] = 1,
		[87204] = 2,
		[41635] = 5,
		[83108] = 2,
		[15532] = "Blackfathom Sea Witch",
		[91810] = 6,
		[93985] = 10,
		[32244] = 4,
		[33831] = 10,
		[3018] = 4,
		[80168] = 8,
		[3026] = 9,
		[50463] = 6,
		[759] = 8,
		[88868] = 1,
		[8129] = 5,
		[63685] = 7,
		[53386] = 6,
		[81192] = 10,
		[8221] = 6,
		[85542] = 9,
		[81576] = "Stonecore Earthshaper",
		[93986] = "Hand of Gul'dan",
		[96161] = 2,
		[49184] = 6,
		[26679] = 4,
		[59547] = 7,
		[49376] = 10,
		[774] = 10,
		[92155] = 1,
		[82728] = 3,
		[47585] = 5,
		[3110] = "Gakuri <Demoncore>",
		[93347] = 9,
		[81193] = "Captive Spirit",
		[781] = 3,
		[74002] = 4,
		[89765] = 4,
		[52127] = 7,
		[46989] = 8,
		[86698] = 2,
		[55775] = 6,
		[62618] = 5,
		[23161] = 9,
		[50464] = 10,
		[101024] = 10,
		[17116] = 10,
		[92799] = 8,
		[6346] = 5,
		[14751] = 5,
		[85288] = 1,
		[85416] = 2,
		[34600] = 3,
		[89766] = "Flaaghun",
		[8690] = 6,
		[92069] = 4,
		[65156] = 1,
		[21562] = 5,
		[59548] = 8,
		[19579] = "Nildara",
		[12880] = 1,
		[57755] = 1,
		[64844] = 5,
		[7103] = 2,
		[853] = 2,
		[25912] = 2,
		[83242] = 3,
		[69041] = 4,
		[81297] = 2,
		[85673] = 2,
		[77613] = 5,
		[32245] = 8,
		[712] = 9,
		[85509] = 2,
		[30294] = 9,
		[50401] = 6,
		[48418] = 10,
		[90363] = 3,
		[82731] = 8,
		[91047] = 8,
		[87081] = "Blackfathom Myrmidon",
		[32182] = 7,
		[83243] = 3,
		[79872] = 1,
		[77616] = 6,
		[3322] = "Cellblock Ooze",
		[81708] = 3,
		[59357] = "Anub'ar Shadowcaster",
		[59421] = "Hadronox",
		[91138] = 2,
		[15407] = 5,
		[45284] = 7,
		[74288] = 8,
		[53600] = 2,
		[33619] = 5,
		[15487] = 5,
		[73680] = 7,
		[22842] = 10,
		[83244] = 3,
		[845] = 1,
		[85547] = 9,
		[77487] = 5,
		[871] = 1,
		[23034] = 1,
		[96294] = 6,
		[703] = 4,
		[73651] = 4,
		[34026] = 3,
		[52752] = 7,
		[86699] = 1,
		[82184] = 9,
		[93827] = 4,
		[49821] = 5,
		[81070] = 10,
		[83245] = 3,
		[81326] = 6,
		[31287] = 10,
		[6898] = 7,
		[73522] = 1,
		[59358] = "Anub'ar Shadowcaster",
		[61391] = 10,
		[82174] = 2,
		[11825] = "Mechanized Guardian",
		[54227] = 3,
		[74290] = 8,
		[88747] = 10,
		[45477] = 6,
		[3490] = "Aku'mai",
		[19740] = 2,
		[79871] = 1,
		[642] = 2,
		[85421] = 9,
		[54049] = "Khuuzhum",
		[77489] = 5,
		[81711] = "Unbound Earth Rager",
		[32246] = 5,
		[12721] = 1,
		[883] = 3,
		[5019] = 8,
		[16191] = 7,
		[48420] = 10,
		[26297] = 4,
		[93816] = 4,
		[30455] = 8,
		[20252] = 1,
		[65116] = 7,
		[89388] = 3,
		[85383] = 9,
		[53652] = 2,
		[8177] = 7,
		[56903] = 6,
		[34795] = 2,
		[43951] = 1,
		[8227] = "Totemica",
		[20572] = 3,
		[53333] = "Anub'ar Necromancer",
		[74292] = 8,
		[53602] = "Anub'ar Darter",
		[86830] = "Millhouse Manastorm",
		[86958] = 7,
		[24858] = 10,
		[91308] = 5,
		[5211] = 10,
		[23246] = 4,
		[34130] = 9,
		[56161] = 5,
		[8435] = "Lady Sarevess",
		[77747] = 7,
		[33836] = 2,
		[54370] = 9,
		[768] = 10,
		[8515] = 7,
		[48421] = "Xnhh",
		[3674] = 3,
		[724] = 5,
		[6807] = 10,
		[16188] = 7,
		[16257] = 7,
		[7386] = 1,
		[91565] = 10,
		[42792] = 9,
		[68766] = 6,
		[7418] = 6,
		[3714] = 6,
		[92205] = 6,
		[79614] = 2,
		[74763] = 6,
		[17534] = 2,
		[74294] = 1,
		[3738] = 7,
		[57761] = 8,
		[89007] = 5,
		[49575] = 5,
		[25914] = 2,
		[324] = 7,
		[81331] = 6,
		[60192] = 3,
		[89775] = 4,
		[35473] = 1,
		[96172] = 2,
		[81021] = 10,
		[54371] = 9,
		[755] = 9,
		[32375] = 5,
		[52437] = 1,
		[66235] = 2,
		[90927] = 7,
		[45462] = 6,
		[20253] = 1,
		[54373] = 9,
		[34477] = 3,
		[79268] = 9,
		[91778] = "Earththief",
		[13281] = "Twilight Elementalist",
		[32727] = 3,
		[53220] = 3,
		[34861] = 5,
		[1159] = 4,
		[30808] = 7,
		[16511] = 4,
		[5675] = 7,
		[88625] = 5,
		[74519] = 10,
		[34720] = 3,
		[87090] = 3,
		[11426] = 8,
		[78990] = 7,
		[75192] = 10,
		[69179] = 1,
		[20925] = 2,
		[9459] = "Cellblock Ooze",
		[23036] = 5,
		[87098] = 8,
		[16959] = 10,
		[3918] = 3,
		[49560] = 6,
		[982] = 3,
		[23228] = 8,
		[44457] = 8,
		[44521] = 2,
		[87091] = 1,
		[48743] = 6,
		[81206] = 5,
		[83381] = "Wolf",
		[63900] = "TRE <Seyren>",
		[7922] = 1,
		[13809] = 3,
		[59362] = "Anub'ar Webspinner",
		[79101] = 2,
		[69820] = 2,
		[20271] = 2,
		[86452] = 2,
		[18562] = 10,
		[68285] = 10,
		[47528] = 6,
		[13953] = "Dun Morogh Mountaineer",
		[80951] = 10,
		[11327] = 4,
		[91809] = "Batstalker",
		[8034] = 7,
		[8042] = 7,
		[8050] = 7,
		[32216] = 1,
		[57319] = 2,
		[85948] = 6,
		[4042] = 2,
		[74001] = 4,
		[54501] = 9,
		[58501] = 1,
		[24252] = 4,
		[8122] = 5,
		[78777] = 10,
		[76858] = 1,
		[32297] = 3,
		[81208] = 5,
		[88748] = 6,
		[53030] = "Hadronox",
		[8178] = 7,
		[8185] = 7,
		[74555] = 1,
		[24604] = "Draco <Ishootthings>",
		[28730] = 5,
		[1134] = 1,
		[53478] = 3,
		[48792] = 6,
		[22717] = 1,
		[49576] = 6,
		[25722] = 1,
		[1044] = 2,
		[22845] = 10,
		[12466] = "Mirror Image <Stayice>",
		[92596] = 5,
		[89653] = 9,
		[91828] = 6,
		[16864] = 10,
		[29178] = 7,
		[73921] = 7,
		[54374] = 9,
		[44203] = 10,
		[1066] = 10,
		[64801] = 10,
		[50536] = 6,
		[16979] = 10,
		[54758] = 3,
		[87095] = 1,
		[19263] = 3,
		[81340] = 6,
		[1082] = 10,
		[55078] = 6,
		[8676] = 4,
		[77762] = 7,
		[59364] = "Watcher Gashra",
		[29722] = 9,
		[53351] = 3,
		[57669] = 2,
		[53479] = 3,
		[92216] = 1,
		[90806] = 1,
		[95799] = 5,
		[53476] = "Scorpid <Gosh>",
		[87096] = 1,
		[59791] = 4,
		[95540] = 1,
		[85433] = 2,
		[10831] = "Arcane Nullifier X-21",
		[85692] = "Doomguard <Beautyy>",
		[1120] = 9,
		[1122] = 9,
		[51178] = 10,
		[54375] = 9,
		[2374] = 4,
		[1130] = 3,
		[32409] = "[*] Shadow Word: Death",
		[71] = 1,
		[23251] = 1,
		[26364] = 7,
		[546] = 7,
		[13218] = 4,
		[63106] = 9,
		[93622] = 10,
		[33395] = "Water Elemental <Sozin>",
		[101033] = 7,
		[92085] = 3,
		[77758] = 10,
		[20511] = 1,
		[73920] = 7,
		[1160] = 1,
		[53480] = 3,
		[92727] = 8,
		[22718] = 4,
		[15473] = 5,
		[52586] = "Krik'thir the Gatewatcher",
		[53800] = "Hadronox",
		[79038] = 8,
		[19647] = "Pryydhum <Yuke>",
		[51945] = 7,
		[64843] = 5,
		[29653] = 3,
		[2367] = 4,
		[33778] = 10,
		[6795] = 10,
		[2379] = 2,
		[73981] = 4,
		[82365] = 10,
		[17057] = 10,
		[75] = 3,
		[44461] = 8,
		[17153] = 2,
		[80146] = "Problim",
		[13730] = 1,
		[43183] = 5,
		[12355] = 8,
		[55080] = 8,
		[6899] = 3,
		[13810] = 3,
		[92089] = 10,
		[22719] = 4,
		[53353] = 3,
		[93811] = 8,
		[23227] = 3,
		[80313] = 10,
		[47468] = "Eyethief",
		[47753] = 5,
		[51690] = 4,
		[53801] = "Anub'ar Crusher",
		[97463] = 1,
		[47788] = 5,
		[11971] = "Blindlight Murloc",
		[91706] = "Flaaghun",
		[78] = 1,
		[94009] = 1,
		[77761] = 10,
		[12051] = 8,
		[89751] = "Flaaghun",
		[56488] = 1,
		[42223] = 9,
		[88751] = 10,
		[80576] = "Ghastly Convict",
		[53401] = "Spirit Beast <Touqing>",
		[34291] = 2,
		[59366] = "Watcher Silthik",
		[58983] = 7,
		[31643] = 8,
		[79683] = 8,
		[25750] = 8,
		[2061] = 5,
		[5116] = 3,
		[92091] = 10,
		[8213] = 7,
		[12323] = 1,
		[53418] = "Hadronox",
		[82368] = 1,
		[33076] = 5,
		[88765] = "Analskweart",
		[8220] = 1,
		[29077] = 8,
		[51755] = 3,
		[34767] = 2,
		[2479] = 2,
		[20578] = 8,
		[71165] = 9,
		[73413] = 5,
		[48045] = 5,
		[5484] = 9,
		[92220] = 3,
		[80066] = 10,
		[48301] = 5,
		[2643] = 3,
		[35098] = 3,
		[86719] = "Flaming Orb",
		[5308] = 1,
		[1330] = 4,
		[81016] = 10,
		[50796] = 9,
		[12723] = 1,
		[50541] = "Bird of Prey <Cornutone>",
		[23455] = 5,
		[85696] = 2,
		[31707] = "Water Elemental <Sozin>",
		[77764] = 10,
		[90174] = 2,
		[31803] = 2,
		[86336] = 2,
		[14914] = 5,
		[52128] = "Totemica",
		[88767] = 7,
		[8118] = 4,
		[55709] = "Spirit Beast <Touqing>",
		[97340] = 2,
		[15039] = "Twilight Elementalist",
		[81219] = 1,
		[84655] = 6,
		[30108] = 9,
		[91838] = "Bonechewer <Mortanius>",
		[8078] = 1,
		[92094] = 4,
		[12042] = 8,
		[59752] = 2,
		[30153] = "Flaaghun",
		[32379] = 5,
		[81463] = "Force of Earth",
		[82627] = 5,
		[5676] = 9,
		[34913] = 8,
		[80964] = 10,
		[13219] = 4,
		[2974] = 3,
		[77767] = 3,
		[91711] = 9,
		[81162] = 6,
		[54158] = 2,
		[57731] = "Hadronox",
		[92223] = 2,
		[18498] = 1,
		[20577] = 8,
		[80325] = 3,
		[92735] = 8,
		[22720] = 10,
		[33206] = 5,
		[51693] = 4,
		[97341] = 1,
		[88691] = 3,
		[13897] = 4,
		[35022] = 5,
		[49966] = "Monkey <Jetblade>",
		[2575] = 2,
		[4987] = 2,
		[92096] = 4,
		[92224] = 6,
		[86211] = 9,
		[2895] = 7,
		[58984] = 10,
		[92736] = 8,
		[1454] = 9,
		[53] = 4,
		[54861] = 9,
		[60103] = 7,
		[81094] = 10,
		[57707] = "Starborn",
		[2983] = 4,
		[85236] = "Forgotten Ghoul",
		[13795] = 3,
		[53390] = 7,
		[64803] = 3,
		[92225] = 2,
		[31804] = 2,
		[94528] = 3,
		[45297] = 7,
		[45334] = 10,
		[5940] = 4,
		[44425] = 8,
		[1490] = 9,
		[19746] = 2,
		[79923] = "Stonecore Flayer",
		[51886] = 7,
		[11972] = "Nethergarde Soldier",
		[37685] = "Ghastly Convict",
		[53400] = "Hadronox",
		[56131] = 5,
		[92098] = 3,
		[92226] = 4,
		[86213] = 9,
		[20066] = 2,
		[48263] = 6,
		[18083] = 2,
		[18990] = 10,
		[10101] = "Mekgineer Thermaplugg",
		[82739] = 8,
		[60970] = 1,
		[50519] = "Dashy",
		[28093] = 1,
		[55021] = 8,
		[95809] = 6,
		[15576] = 1,
		[8187] = 7,
		[92099] = 10,
		[63529] = 2,
		[18499] = 1,
		[57516] = 1,
		[97954] = 1,
		[30451] = 8,
		[22721] = 8,
		[91376] = 1,
		[1064] = 7,
		[50288] = 10,
		[76663] = 3,
		[8374] = "Twilight Reaver",
		[60202] = 3,
		[41252] = 4,
		[33912] = "Rocknail Ripper",
		[53290] = 3,
		[12548] = "Twilight Elementalist",
		[51185] = 10,
		[90309] = "KRUSHER",
		[94318] = 9,
		[58604] = "Core Hound <Drendels>",
		[42292] = 10,
		[99] = 10,
		[30802] = 7,
		[2062] = 7,
		[55342] = 8,
		[101568] = 6,
		[59052] = 8,
		[79477] = 4,
		[25504] = 7,
		[100] = 1,
		[88263] = 2,
		[75447] = 3,
		[1604] = "Anub'ar Champion",
		[10789] = 4,
		[85234] = "Hungry Ghoul",
		[3219] = 5,
		[33081] = 2,
		[1038] = 2,
		[12292] = 1,
		[95172] = "Argaloth",
		[47666] = 5,
		[12964] = 1,
		[58861] = "Spirit Wolf <Xcite>",
		[79922] = "Stonecore Flayer",
		[2050] = 5,
		[77517] = 10,
		[86346] = 1,
		[33082] = 4,
		[53616] = "Anub'ar Venomancer",
		[50245] = "Seggszag",
		[20707] = 9,
		[58605] = "Core Hound <Drendels>",
		[6572] = 1,
		[91336] = 6,
		[69369] = 10,
		[95173] = "Argaloth",
		[79476] = 10,
		[18244] = "Siorbaczysko",
		[15571] = 3,
		[92104] = 7,
		[79437] = 9,
		[91374] = 2,
		[73552] = 2,
		[6660] = "Lady Sarevess",
		[56815] = 6,
		[17253] = "Draco <Ishootthings>",
		[47283] = 9,
		[74192] = 9,
		[51505] = 7,
		[22722] = 3,
		[1680] = 1,
		[26880] = 6,
		[74194] = 2,
		[81101] = 1,
		[62124] = 2,
		[57519] = 1,
		[79438] = 9,
		[15587] = "Twilight Lord Kelris",
		[47476] = 6,
		[73681] = 7,
		[56112] = 1,
		[12053] = 4,
		[20164] = 2,
		[1706] = 5,
		[105284] = 7,
		[79859] = 8,
		[1784] = 4,
		[1714] = 9,
		[19236] = 5,
		[93932] = 3,
		[34490] = 3,
		[34936] = 9,
		[96201] = "yes <Veganpets>",
		[68055] = 2,
		[13812] = 3,
		[63468] = 3,
		[49203] = 6,
		[90314] = "Koda",
		[6940] = 2,
		[76241] = 6,
		[22723] = 2,
		[1742] = "Doge <Exor>",
		[51699] = "Syph",
		[51698] = 4,
		[64044] = 5,
		[87023] = 8,
		[1752] = 4,
		[87118] = 5,
		[26017] = 2,
		[23243] = 10,
		[88686] = 5,
		[73683] = 7,
		[50227] = 1,
		[90315] = "Koda",
		[40120] = 10,
		[42231] = 10,
		[86605] = 10,
		[101062] = 5,
		[1776] = 4,
		[95177] = "Fel Flames",
		[87117] = 5,
		[79057] = 8,
		[89420] = 9,
		[24450] = "Cat",
		[79058] = 8,
		[52419] = 6,
		[81744] = 8,
		[20484] = 10,
		[18469] = 8,
		[5221] = 10,
		[3599] = 7,
		[74196] = 8,
		[94794] = 2,
		[53618] = "Anub'ar Guardian",
		[78674] = 10,
		[95178] = "Demon Containment Unit",
		[35387] = "GothBoi",
		[91340] = 1,
		[16870] = 10,
		[7268] = 8,
		[91724] = 5,
		[1822] = 10,
		[25058] = "Scarlet Chaplain",
		[73685] = 7,
		[48181] = 9,
		[79858] = 8,
		[5277] = 4,
		[82897] = 3,
		[44535] = 8,
		[8647] = 4,
		[78675] = 10,
		[1842] = 4,
		[8395] = 8,
		[91341] = 6,
		[8379] = "Blackfathom Myrmidon",
		[1850] = 10,
		[55090] = 6,
		[61295] = 7,
		[1856] = 4,
		[95466] = "GothBoi",
		[8679] = 4,
		[17510] = 4,
		[5405] = 8,
		[74198] = 9,
		[51700] = 4,
		[31935] = 2,
		[83154] = 8,
		[57841] = 4,
		[54131] = "Draco <Ishootthings>",
		[79060] = 10,
		[92651] = "[*] Thrashing Charge",
		[30823] = 7,
		[48438] = 10,
		[118] = 8,
		[32223] = 2,
		[52212] = 6,
		[20165] = 2,
		[24131] = 3,
		[84306] = "Drowned Gilnean Settler",
		[50421] = 6,
		[52532] = "Anub'ar Warrior",
		[24259] = "Pryydhum <Yuke>",
		[50613] = 6,
		[41637] = 5,
		[3815] = "Aku'mai",
		[79061] = 10,
		[20815] = "Scarlet Diviner",
		[26562] = 10,
		[57330] = 6,
		[120] = 8,
		[81748] = 6,
		[94158] = 1,
		[49206] = 6,
		[20549] = 2,
		[11366] = 8,
		[92623] = "Stonecore Berserker",
		[5677] = 7,
		[22724] = 4,
		[51637] = 4,
		[51701] = 4,
		[36554] = 4,
		[79062] = 2,
		[3564] = 2,
		[7812] = "Ormlos",
		[54785] = 9,
		[122] = 8,
		[84308] = "Drowned Gilnean Settler",
		[96206] = 10,
		[48503] = 10,
		[84590] = 4,
		[3919] = 3,
		[50422] = 6,
		[46392] = "Kryptz",
		[1966] = 4,
		[92650] = "Corborus",
		[91345] = 2,
		[53301] = 3,
		[79063] = 2,
		[13877] = 4,
		[31616] = 7,
		[17735] = "Graz'juk",
		[13797] = 3,
		[13813] = 3,
		[25603] = "Twilight Loreseeker",
		[94288] = 2,
		[53365] = "Aeglos",
		[45241] = 5,
		[17767] = "Jhaztaz <Cthulhudie>",
		[58227] = 5,
		[81751] = 5,
		[11977] = 1,
		[8004] = 7,
		[19750] = 2,
		[2006] = 5,
		[11958] = 8,
		[8076] = 7,
		[92626] = "Stonecore Earthshaper",
		[35710] = 5,
		[52150] = 6,
		[88660] = 8,
		[94289] = 2,
		[4043] = "Dark Iron Land Mine <Dark Iron Agent>",
		[2024] = 8,
		[52470] = "Watcher Gashra",
		[46393] = "Dksita",
		[48504] = 10,
		[82926] = 3,
		[58867] = "Spirit Wolf <Xcite>",
		[20230] = 1,
		[52534] = "Anub'ar Shadowcaster",
		[30482] = 8,
		[65264] = 7,
		[1978] = 3,
		[49016] = 6,
		[32736] = 1,
		[12294] = 1,
		[35018] = 8,
		[8232] = 7,
		[16488] = 1,
		[331] = "Budala",
		[30070] = 1,
		[6197] = "Pilin",
		[779] = 10,
		[130] = 8,
		[2096] = 5,
		[6229] = 9,
		[12470] = "Greater Fire Elemental <Nvd>",
		[79471] = 7,
		[81141] = 6,
		[52087] = 2,
		[83744] = 9,
		[12550] = "Lorgus Jett",
		[2120] = 8,
		[133] = 8,
		[72286] = 2,
		[92628] = "Force of Earth",
		[2136] = 8,
		[48505] = 10,
		[23338] = 10,
		[52535] = "Anub'ar Shadowcaster",
		[23333] = 2,
		[47541] = 6,
		[51124] = 6,
		[6117] = 8,
		[82415] = "Corborus",
		[23493] = 5,
		[8391] = "Aku'mai Snapjaw",
		[35711] = 8,
		[27683] = 5,
		[136] = 3,
		[79854] = 8,
		[24932] = 10,
		[85739] = 1,
		[74663] = 2,
		[75614] = 8,
		[10887] = "Crowd Pummeler 9-60",
		[80987] = 8,
		[139] = 5,
		[20007] = 1,
		[17800] = 9,
		[47930] = 5,
		[30146] = 9,
		[77661] = 7,
		[19975] = 10,
		[86105] = 9,
		[90327] = "Young Mastiff <Murderouz>",
		[36032] = 8,
		[92630] = "Rock Borer",
		[91368] = 1,
		[20167] = 2,
		[9080] = 1,
		[15237] = 5,
		[8936] = 10,
		[34433] = 5,
		[78830] = 8,
		[32242] = 1,
		[55095] = "Aeglos",
		[51585] = 4,
		[6653] = 4,
		[8680] = 4,
		[74208] = 1,
		[90328] = "Spirit Beast <Battlefield>",
		[18540] = 9,
		[59637] = "Mirror Image <Fallenlight>",
		[13398] = "Leprous Machinesmith",
		[61684] = "Doge <Exor>",
		[94310] = 10,
		[57846] = "Nethergarde Defender",
		[32289] = 2,
		[91352] = 6,
		[63731] = 5,
		[93655] = "Mekgineer Thermaplugg",
		[91351] = 2,
		[64371] = 9,
		[6533] = "Gelihast",
		[6789] = 9,
		[1126] = 10,
		[34471] = 3,
		[71521] = 9,
		[79140] = 4,
		[52537] = 2,
		[44413] = 8,
		[25317] = "Werni",
		[1022] = 2,
		[31801] = 2,
		[93400] = 10,
		[13750] = 5,
		[9672] = "Twilight Aquamancer",
		[86700] = 2,
		[5487] = 10,
		[31842] = 2,
		[102740] = 2,
		[56446] = 3,
		[17481] = 10,
		[55480] = 2,
		[61685] = "Gitanas <Gitanus>",
		[51514] = 7,
		[90842] = 8,
		[59830] = 4,
		[82654] = 3,
		[53817] = 7,
		[88334] = 2,
		[66842] = 7,
		[2484] = 7,
		[35714] = 5,
		[98007] = 7,
		[12023] = 10,
		[92122] = "[*] Crystal Shards",
		[32290] = 1,
		[19883] = 3,
		[102741] = 2,
		[85144] = 2,
		[58679] = 6,
		[52538] = "Anub'ar Skirmisher",
		[12968] = 1,
		[12167] = "Blindlight Oracle",
		[16277] = 7,
		[91355] = 1,
		[93402] = 10,
		[92123] = 10,
		[10] = 8,
		[98008] = 7,
		[5118] = 3,
		[10248] = 2,
		[16490] = 1,
		[45182] = 4,
		[102742] = 7,
		[80353] = 8,
		[2584] = 3,
		[45438] = 8,
		[32243] = 1,
		[20424] = 2,
		[35395] = 2,
		[51963] = "Ebon Gargoyle <Epstein>",
		[12471] = "Fallenroot Hellcaller",
		[8393] = "Barbed Crustacean",
		[58168] = 8,
		[53434] = "Spirit Beast",
		[5246] = 1,
		[57984] = "Greater Fire Elemental <Nvd>",
		[53318] = "Anub'ar Crusher",
		[32546] = 5,
		[441] = 10,
		[80354] = 2,
		[31818] = 9,
		[6136] = "Blackfathom Sea Witch",
		[5217] = 10,
		[84960] = 9,
		[23335] = 5,
		[49020] = 6,
		[6358] = "Glyaith",
		[96219] = 5,
		[79459] = 9,
		[84968] = 8,
		[5374] = 4,
		[25606] = 1,
		[17450] = 8,
		[32901] = "The Lone Hunter",
		[102744] = 10,
		[80483] = 3,
		[53563] = 2,
		[23241] = 10,
		[55610] = 6,
		[92644] = "Millhouse Manastorm",
		[31665] = 4,
		[12967] = 1,
		[79460] = 9,
		[25990] = 5,
		[15062] = 1,
		[172] = 9,
		[69826] = 2,
		[8921] = 10,
		[17962] = 9,
		[2764] = 5,
		[32707] = 9,
		[2812] = 2,
		[52540] = "Anub'ar Skirmisher",
		[13159] = 3,
		[86881] = "Corborus",
		[44544] = 8,
		[73325] = 5,
		[65142] = 6,
		[15286] = 5,
		[22568] = 10,
		[102746] = 5,
		[85730] = 1,
		[8362] = "Blindlight Oracle",
		[94686] = 2,
		[88161] = "Pedal",
		[4167] = "DDShlongLegs <Yazura>",
		[16491] = 1,
		[63735] = 5,
		[100955] = 7,
		[61882] = 7,
		[79206] = 7,
		[84963] = 2,
		[9433] = "Arcanist Doan",
		[70890] = 6,
		[60089] = 10,
		[5782] = 9,
		[79462] = 9,
		[102747] = 7,
		[2908] = 10,
		[77799] = 9,
		[2912] = 10,
		[90337] = "Monkey",
		[64695] = "Earthbind Totem",
		[77800] = "Budala",
		[86627] = 1,
		[82661] = 3,
		[50622] = 1,
		[63544] = 5,
		[102748] = 8,
		[57723] = "Enigma",
		[83301] = 2,
		[3044] = 3,
		[79463] = 9,
		[55164] = 8,
		[19434] = 3,
		[2948] = 8,
		[88163] = 1,
		[32612] = 8,
		[59578] = 2,
		[92641] = "Millhouse Manastorm",
		[91363] = 6,
		[19658] = "Traaghun <Ivylab>",
		[16278] = 7,
		[58875] = 7,
		[77801] = 9,
		[23880] = 1,
		[83302] = 8,
		[95712] = 3,
		[20170] = 2,
		[58683] = 9,
		[32388] = 9,
		[30213] = "Flaaghun",
		[32292] = 2,
		[16166] = 7,
		[58427] = 4,
		[92642] = "Millhouse Manastorm",
		[88676] = 2,
		[14183] = 4,
		[16246] = 7,
		[84966] = 1,
		[83047] = 2,
		[70893] = 3,
		[81256] = 6,
		[79848] = 8,
		[83559] = 3,
		[85222] = 2,
		[49088] = 6,
		[79849] = "Horde Mage Infantry",
		[2944] = 5,
		[12328] = 1,
		[88421] = "Problim",
		[35079] = 3,
		[17099] = 10,
		[57724] = "Midoo",
		[55741] = 6,
		[30981] = 3,
		[43265] = 6,
		[91364] = 1,
		[12472] = 8,
		[8394] = 4,
		[93795] = 1,
		[6262] = 9,
		[12536] = 8,
		[23229] = 3,
		[10799] = 3,
		[11831] = 5,
		[23145] = "Dashy",
		[74221] = 4,
		[84584] = 1,
		[86759] = 4,
		[86624] = 1,
		[82921] = 3,
		[65081] = 5,
		[81130] = 6,
		[31589] = 8,
		[36936] = 7,
		[83562] = "Accursed Longshoreman",
		[46968] = 1,
		[86704] = 2,
		[51714] = 6,
		[22570] = 10,
		[10793] = 10,
		[57934] = 4,
		[42955] = 8,
		[84585] = 1,
		[34428] = 1,
		[10873] = 4,
		[84969] = 3,
		[64058] = 5,
		[23881] = 1,
		[39104] = 7,
		[91021] = 4,
		[10969] = 5,
		[91722] = 2,
		[3264] = "The Lone Hunter",
		[96228] = 10,
		[86121] = 9,
		[20043] = 3,
		[59638] = "Mirror Image <Fallenlight>",
		[32389] = 9,
		[84586] = 1,
		[11113] = 8,
		[11129] = 8,
		[81700] = 5,
		[53517] = 3,
		[2060] = 5,
		[77535] = 6,
		[32645] = 4,
		[79469] = 6,
		[80861] = 10,
		[3606] = 7,
		[96229] = 6,
		[34889] = "Young Dragonhawk <Saimi>",
		[34953] = 3,
		[63675] = 5,
		[74224] = 5,
		[32592] = 5,
		[16589] = 2,
		[8075] = 7,
		[51713] = 4,
		[6726] = 5,
		[22858] = 1,
		[81261] = 10,
		[20875] = 1,
		[79470] = 7,
		[98021] = 7,
		[64343] = 8,
		[96230] = 2,
		[94311] = 9,
		[12975] = 1,
		[3408] = 4,
		[92648] = "Corborus",
		[50498] = "Raptor",
		[23242] = 3,
		[90985] = 9,
		[82925] = 3,
		[48707] = 6,
		[48265] = 6,
		[81262] = 10,
		[8398] = "Aku'mai Servant",
		[46916] = 1,
		[61309] = 5,
		[96103] = 1,
		[96231] = 2,
		[94312] = 9,
		[45242] = 5,
		[84333] = 8,
		[23690] = 1,
		[12809] = 1,
		[528] = 5,
		[50163] = 6,
		[80879] = 10,
		[46585] = 6,
		[91370] = 1,
		[8092] = 5,
		[87532] = 5,
		[79472] = 6,
		[30151] = "Flaaghun",
		[32064] = "Lord Falconcrest",
		[52086] = "Anub'ar Webspinner",
		[94313] = 9,
		[49143] = 6,
		[17511] = 2,
		[50435] = 6,
		[88684] = 5,
		[52610] = 10,
		[52469] = "Watcher Silthik",
		[58879] = "Spirit Wolf <Xcite>",
		[44614] = 8,
		[24394] = 3,
		[59071] = 10,
		[92624] = "Force of Earth",
		[57842] = 4,
		[49028] = 6,
		[55233] = 6,
		[79857] = 8,
		[8219] = 1,
		[18118] = 9,
		[3600] = "Earthbind Totem <Totemica>",
		[3604] = "The Lone Hunter",
		[88685] = 5,
		[10346] = "Mechano-Tank",
		[59888] = 5,
		[82928] = 3,
		[20154] = 2,
		[62078] = 10,
		[5215] = 10,
		[16782] = 2,
		[116] = 8,
		[95179] = "Demon Containment Unit",
		[7294] = 2,
		[7302] = 8,
		[18989] = 10,
		[33660] = 8,
		[64701] = 7,
		[5229] = 10,
		[56641] = 3,
		[48517] = 10,
		[90989] = 8,
		[54786] = 9,
		[87151] = 5,
		[95467] = "Raptor",
		[10326] = 2,
		[53490] = "sosa",
		[3583] = 10,
		[31687] = 8,
		[34299] = "Verocchio",
		[3716] = "Ormlos",
		[17454] = 5,
		[1766] = 4,
		[35020] = 5,
		[51460] = 6,
		[57840] = 4,
		[84721] = 8,
		[73682] = 7,
		[82930] = 8,
		[87152] = 5,
		[47750] = 5,
		[3411] = 1,
		[6788] = 5,
		[93805] = 8,
		[64382] = 1,
		[59887] = 5,
		[59566] = "Earthbind Totem <Drezzd>",
		[32295] = 3,
		[73975] = 6,
		[91797] = "Carrionstalker <Epstein>",
		[54172] = 2,
		[88688] = 2,
		[48518] = 10,
		[11130] = "Mekgineer Thermaplugg",
		[86316] = 3,
		[87153] = 5,
		[81140] = 1,
		[63167] = 9,
		[95746] = 10,
		[93806] = 1,
		[92071] = 3,
		[66] = 8,
		[19885] = 3,
		[49222] = 6,
		[80117] = 1,
		[20589] = 6,
		[54314] = "Anub'ar Prime Guard",
		[22910] = 3,
		[16591] = 4,
		[90992] = 5,
		[15496] = "Stonecore Warbringer",
		[81459] = "Stonecore Earthshaper",
		[24907] = 10,
		[81269] = 10,
		[88749] = 7,
		[9435] = "Arcanist Doan",
		[33377] = 2,
		[69070] = 4,
		[7814] = "Lynora <Demoncore>",
		[94319] = 9,
		[9515] = 1,
		[59628] = 4,
		[48391] = 10,
		[34976] = 7,
		[246] = "Lady Sarevess",
		[7870] = "Vilriel",
		[80886] = 10,
		[29502] = 3,
		[13737] = "Okril'lon Infantry",
		[33786] = 10,
		[14177] = 4,
		[101423] = 2,
		[79607] = 10,
		[81782] = 5,
		[11981] = "Scarlet Diviner",
		[11802] = "Dark Iron Agent",
		[55428] = 10,
		[29801] = 1,
		[53509] = "Anub'arak",
		[25771] = 2,
		[88819] = 2,
		[82806] = 2,
		[64420] = 3,
		[23035] = 2,
		[64128] = 5,
		[11962] = 9,
		[99621] = 3,
		[58179] = 10,
		[54149] = 2,
		[48108] = 8,
		[54277] = 9,
		[32296] = 5,
		[90355] = 3,
		[55637] = 5,
		[59913] = "Ushi",
		[80965] = 10,
		[14185] = 4,
		[80760] = 2,
		[23451] = 2,
		[18223] = 9,
		[34447] = 8,
		[31224] = 4,
		[46857] = 1,
		[79481] = 3,
		[71757] = 8,
		[8190] = 7,
		[89265] = 10,
		[51271] = 6,
		[47241] = 9,
		[51399] = 6,
		[3355] = 3,
		[96171] = 6,
		[55277] = 7,
		[90996] = 8,
		[6770] = 4,
		[81017] = 10,
		[8364] = "Blackfathom Sea Witch",
		[89906] = 2,
		[596] = 5,
		[58180] = 10,
		[77769] = 3,
		[74434] = 9,
		[33143] = 5,
		[94323] = 9,
		[56453] = 3,
		[79102] = 2,
		[25228] = 9,
		[53138] = 6,
		[92218] = 2,
		[48982] = 6,
		[6343] = 1,
		[51052] = 6,
		[1079] = 10,
		[68992] = 10,
		[1462] = 3,
		[17] = 5,
		[31930] = 2,
		[80166] = 5,
		[96243] = 8,
		[19503] = 3,
		[13165] = 3,
		[86392] = 9,
		[33702] = 9,
		[100977] = 10,
		[25804] = 6,
		[54290] = "Anub'ar Webspinner",
		[82938] = 3,
		[87160] = 5,
		[23885] = 1,
		[633] = 2,
		[85497] = 2,
		[93368] = 3,
		[29341] = 9,
		[33745] = 10,
		[83582] = 8,
		[8988] = "Arcanist Doan",
		[48266] = 6,
		[1129] = 8,
		[1131] = 8,
		[1133] = 7,
		[1135] = 5,
		[1137] = 5,
		[82939] = 3,
		[32553] = 9,
		[48778] = 6,
		[71041] = "Nvd",
		[87545] = 6,
		[92087] = 4,
		[81660] = 5,
		[34769] = "Patladin",
		[80003] = 3,
		[90811] = 2,
		[63619] = "Shadowfiend <Outlandish>",
		[35025] = 3,
		[470] = 4,
		[82626] = 5,
		[16593] = 9,
		[84751] = 5,
		[82940] = 1,
		[16689] = 10,
		[47755] = 5,
		[6307] = 9,
		[84480] = 2,
		[13530] = 1,
		[81661] = 5,
		[54216] = 3,
		[9484] = 5,
		[55001] = 9,
		[90361] = "Spirit Beast <Touqing>",
		[5171] = 4,
		[74241] = 8,
		[23214] = 2,
		[74497] = 10,
		[8733] = 5,
		[82941] = 1,
		[81022] = 10,
		[66196] = 6,
		[68996] = 10,
		[87547] = 7,
		[46924] = 1,
		[97462] = 1,
		[59348] = "Anub'ar Crypt Fiend",
		[53257] = 3,
		[80169] = 5,
		[53385] = 2,
		[31850] = 2,
		[23694] = 1,
		[2457] = 1,
		[50518] = "Tangerine",
		[91002] = 7,
		[51722] = 4,
		[80009] = 3,
		[79104] = 5,
		[89753] = "Flaaghun",
		[25997] = 2,
		[52042] = 7,
		[12976] = 1,
		[13376] = "Greater Fire Elemental <Nvd>",
		[12043] = 8,
		[74513] = 9,
		[30283] = 9,
		[58567] = 1,
		[10060] = 5,
		[53656] = 2,
		[59754] = 6,
		[14202] = 1,
		[53472] = "Anub'arak",
		[5740] = 9,
		[79105] = 5,
		[81280] = "Bloodworm <Qloom>",
		[17941] = 9,
		[1719] = 1,
		[26573] = 2,
		[32746] = 2,
		[2565] = 1,
		[92283] = 8,
		[90364] = "Silithid",
		[35027] = 2,
		[53657] = 2,
		[22703] = 9,
		[10348] = "Leprous Machinesmith",
		[67481] = "Monkey",
		[82944] = 3,
		[8349] = 7,
		[93435] = 3,
		[49868] = 5,
		[10444] = 7,
		[22959] = 8,
		[64657] = 10,
		[86150] = 2,
		[16914] = 10,
		[33876] = 10,
		[2637] = 10,
		[2641] = 3,
		[2645] = 7,
		[2649] = "Draco <Ishootthings>",
		[23247] = 7,
		[1329] = 4,
		[82945] = 3,
		[83073] = 8,
		[79107] = 5,
		[36563] = 4,
		[55050] = 6,
		[63058] = 10,
		[10732] = "Leprous Machinesmith",
		[21395] = 5,
		[5384] = 3,
		[96379] = 9,
		[10796] = 8,
		[22482] = 4,
		[25742] = 2,
		[92797] = 8,
		[87563] = 6,
		[41425] = 8,
		[84993] = 1,
		[70940] = 2,
		[5225] = 10,
		[81283] = "Wild Mushroom <Papachop>",
		[90889] = 8,
		[93821] = 9,
		[17080] = 10,
		[32235] = 8,
		[54181] = 9,
		[6360] = "Vilriel",
		[9005] = 10,
		[88448] = 9,
		[24529] = "Raptor <Unknown>",
		[87718] = 7,
		[348] = 9,
		[5568] = "Ghamoo-ra",
		[91135] = 2,
		[91776] = "Army of the Dead Ghoul <Aeglos>",
		[72968] = 1,
		[15290] = 5,
		[73630] = 2,
		[974] = 7,
		[34709] = 2,
		[32747] = 2,
		[13323] = "Arcanist Doan",
		[2825] = 7,
		[94462] = 5,
		[96266] = 5,
		[355] = 1,
		[51533] = 7,
		[82692] = 3,
		[51490] = 7,
		[82948] = 3,
		[96267] = 5,
		[57994] = 7,
		[17364] = 7,
		[56222] = 6,
		[49998] = 6,
		[77575] = 6,
		[33750] = 7,
		[79878] = 1,
		[33878] = 10,
		[5784] = 9,
		[1449] = 8,
		[87958] = 8,
		[92800] = 8,
		[23248] = 1,
		[25746] = 2,
		[9613] = "Twilight Shadowmage",
		[83077] = 3,
		[1463] = 8,
		[54372] = 9,
		[21393] = 1,
		[20473] = 2,
		[49039] = 6,
		[13819] = 2,
		[16190] = 7,
		[19506] = 3,
		[11820] = "Mechanized Guardian",
		[80263] = 4,
		[31884] = 2,
		[770] = 10,
		[2973] = 3,
		[47568] = 6,
		[47632] = 6,
		[86005] = "Saphira",
		[91394] = 8,
		[23920] = 1,
		[1499] = 3,
		[93825] = 3,
		[20217] = 2,
		[52174] = 1,
		[8071] = 7,
		[31790] = 2,
		[20050] = 2,
		[1513] = 3,
		[379] = 7,
		[92802] = 8,
		[20178] = 2,
		[85540] = 9,
		[3045] = 3,
		[8143] = 7,
		[980] = 9,
		[78989] = 10,
		[20187] = 2,
	},
	["encounter_spell_pool"] = {
		{
			47120, -- [1]
			"Argaloth", -- [2]
		}, -- [1]
		[95172] = {
			47120, -- [1]
			"Argaloth", -- [2]
		},
		[95173] = {
			47120, -- [1]
			"Argaloth", -- [2]
		},
		[80028] = {
			43438, -- [1]
			"Rock Borer", -- [2]
		},
		[92630] = {
			43438, -- [1]
			"Rock Borer", -- [2]
		},
		[86881] = {
			43438, -- [1]
			"Corborus", -- [2]
		},
		[95177] = {
			47120, -- [1]
			"Fel Flames", -- [2]
		},
		[81828] = {
			43438, -- [1]
			"[*] Thrashing Charge", -- [2]
		},
		[32409] = {
			47120, -- [1]
			"[*] Shadow Word: Death", -- [2]
		},
		[774] = {
			47120, -- [1]
			10, -- [2]
		},
		[92650] = {
			43438, -- [1]
			"Corborus", -- [2]
		},
		[92122] = {
			43438, -- [1]
			"[*] Crystal Shards", -- [2]
		},
		[92648] = {
			43438, -- [1]
			"Corborus", -- [2]
		},
		[88972] = {
			47120, -- [1]
			"Argaloth", -- [2]
		},
		[47008] = {
			47120, -- [1]
			"Argaloth", -- [2]
		},
		[92651] = {
			43438, -- [1]
			"[*] Thrashing Charge", -- [2]
		},
		[82415] = {
			43438, -- [1]
			"Corborus", -- [2]
		},
	},
	["npcid_ignored"] = {
	},
	["dungeon_data"] = {
	},
	["got_first_run"] = true,
	["report_pos"] = {
		1, -- [1]
		1, -- [2]
	},
	["latest_report_table"] = {
	},
	["__profiles"] = {
		["Jsea-Maelstrom"] = {
			["show_arena_role_icon"] = false,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[259] = {
					0.75, -- [1]
					0.875, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[260] = {
					0.875, -- [1]
					1, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["tooltip"] = {
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["tooltip_max_pets"] = 2,
				["anchor_relative"] = "top",
				["abbreviation"] = 2,
				["anchored_to"] = 1,
				["show_amount"] = false,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["background"] = {
					0.196, -- [1]
					0.196, -- [2]
					0.196, -- [3]
					0.8697, -- [4]
				},
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["commands"] = {
				},
				["tooltip_max_abilities"] = 6,
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["maximize_method"] = 1,
				["border_size"] = 14,
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.9240000152587891, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.2,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = true,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["current_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["sample_size"] = 5,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = false,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = false,
					["height"] = 65,
					["width"] = 220,
				},
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["animation_speed"] = 33,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["disable_window_groups"] = false,
			["instances_suppress_trash"] = 0,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type_original"] = 2,
			["default_bg_alpha"] = 0.5,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["time_type"] = 2,
			["death_tooltip_width"] = 350,
			["animate_scroll"] = false,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -3.501426664144672e-005,
							["x"] = 7.002853328289343e-005,
							["w"] = 309.9999998632255,
							["h"] = 158.0000222942401,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["clickthrough_window"] = false,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.0941176470588235,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["micro_displays_locked"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 12,
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
						},
						["font_size"] = 16,
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\BantoBar",
						["texture_custom_file"] = "Interface\\",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textR_bracket"] = "(",
						["use_spec_icons"] = true,
						["textR_enable_custom_text"] = false,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "BantoBar",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["textL_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["texture_background"] = "Details D'ictum (reverse)",
						["textR_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["start_after_icon"] = true,
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["percent_type"] = 1,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
					},
					["ignore_mass_showhide"] = false,
					["plugins_grow_direction"] = 1,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["desaturated_menu"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.0941176470588235,
					["bg_b"] = 0.0941176470588235,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						0.0705882352941177, -- [1]
						0.0705882352941177, -- [2]
						0.0705882352941177, -- [3]
						0.639196664094925, -- [4]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["StatusBarSaved"] = {
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 0,
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 6,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["show_statusbar"] = false,
					["__was_opened"] = true,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["menu_icons_size"] = 0.850000023841858,
					["hide_in_combat_alpha"] = 0,
					["switch_healer_in_combat"] = false,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["libwindow"] = {
						["y"] = -5.252139987987903e-005,
						["x"] = 0.0001050427997597581,
						["point"] = "CENTER",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["bars_inverted"] = false,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["bars_sort_direction"] = 1,
					["bg_alpha"] = 0.183960914611816,
					["switch_damager_in_combat"] = false,
					["grab_on_top"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["clickthrough_rows"] = false,
					["auto_current"] = true,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["text_face"] = "Accidental Presidency",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["enable_custom_text"] = false,
						["show_timer"] = {
							true, -- [1]
							true, -- [2]
							true, -- [3]
						},
					},
					["bars_grow_direction"] = 1,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -3.501426664144672e-005,
							["x"] = 7.002853328289343e-005,
							["w"] = 309.9999998632255,
							["h"] = 158.0000222942401,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["switch_tank"] = false,
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["switch_all_roles_after_wipe"] = false,
					["switch_damager"] = false,
					["show_sidebars"] = false,
					["skin_custom"] = "",
				}, -- [1]
			},
			["report_lines"] = 5,
			["clear_ungrouped"] = true,
			["pvp_as_group"] = true,
			["skin"] = "WoW Interface",
			["override_spellids"] = true,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["force_activity_time_pvp"] = true,
			["numerical_system"] = 1,
			["overall_clear_logout"] = false,
			["minimum_combat_time"] = 5,
			["memory_threshold"] = 3,
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["MAGE"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["PET"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DRUID"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.25, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["UNKNOW"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PRIEST"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["Alliance"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["ROGUE"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["Horde"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["SHAMAN"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
			},
			["overall_flag"] = 16,
			["disable_alldisplays_window"] = false,
			["numerical_system_symbols"] = "auto",
			["trash_auto_remove"] = true,
			["total_abbreviation"] = 2,
			["segments_amount_to_save"] = 18,
			["clear_graphic"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["default_bg_color"] = 0.0941,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["deny_score_messages"] = false,
			["segments_auto_erase"] = 1,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["ARENA_GREEN"] = {
					0.4, -- [1]
					1, -- [2]
					0.4, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["version"] = 1,
			},
			["segments_panic_mode"] = false,
			["standard_skin"] = false,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["overall_clear_newboss"] = true,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["report_schema"] = 1,
			["use_scroll"] = false,
			["use_battleground_server_parser"] = false,
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["segments_amount"] = 18,
			["instances_no_libwindow"] = false,
			["deadlog_limit"] = 16,
			["instances_segments_locked"] = true,
		},
		["Gsea-Maelstrom"] = {
			["show_arena_role_icon"] = false,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = false,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[259] = {
					0.75, -- [1]
					0.875, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[260] = {
					0.875, -- [1]
					1, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["tooltip"] = {
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["tooltip_max_pets"] = 2,
				["anchor_relative"] = "top",
				["abbreviation"] = 2,
				["anchored_to"] = 1,
				["show_amount"] = false,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["background"] = {
					0.196, -- [1]
					0.196, -- [2]
					0.196, -- [3]
					0.8, -- [4]
				},
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["commands"] = {
				},
				["tooltip_max_abilities"] = 6,
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["fontshadow"] = true,
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["border_size"] = 14,
				["maximize_method"] = 1,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.9240000152587891, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["icon_border_texcoord"] = {
					["R"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["B"] = 0.921875,
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["update_speed"] = 3,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = true,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["current_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["sample_size"] = 5,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = false,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = false,
					["height"] = 65,
					["width"] = 220,
				},
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["animation_speed"] = 33,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["disable_window_groups"] = false,
			["instances_suppress_trash"] = 0,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["instances_segments_locked"] = true,
			["deadlog_limit"] = 16,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["instances_no_libwindow"] = false,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -437.0000580607663,
							["x"] = 748.5557199052892,
							["w"] = 209.5553960917103,
							["h"] = 85.99997579091723,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.850000023841858,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.09411764705882353,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["micro_displays_locked"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["clickthrough_rows"] = false,
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["desaturated_menu"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.09411764705882353,
					["bg_b"] = 0.09411764705882353,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.07058823529411765, -- [1]
						0.07058823529411765, -- [2]
						0.07058823529411765, -- [3]
						0, -- [4]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["segmentType"] = 2,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["timeType"] = 1,
								["textXMod"] = 6,
								["textAlign"] = 0,
								["textFace"] = "Accidental Presidency",
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["__locked"] = true,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["show_statusbar"] = false,
					["__was_opened"] = true,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["clickthrough_window"] = false,
					["hide_in_combat_alpha"] = 0,
					["bg_alpha"] = 0,
					["stretch_button_side"] = 1,
					["libwindow"] = {
						["y"] = 0,
						["x"] = 0,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0,
						["overlay"] = {
							0.07058823529411765, -- [1]
							0.07058823529411765, -- [2]
							0.07058823529411765, -- [3]
						},
					},
					["backdrop_texture"] = "None",
					["bars_grow_direction"] = 1,
					["auto_hide_menu"] = {
						["left"] = true,
						["right"] = false,
					},
					["bars_sort_direction"] = 1,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["switch_damager_in_combat"] = false,
					["grab_on_top"] = false,
					["bars_inverted"] = false,
					["auto_current"] = true,
					["row_info"] = {
						["textR_outline"] = true,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = true,
						["textR_outline_small"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["percent_type"] = 1,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 0,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Fonts\\ARIALN.TTF",
						["backdrop"] = {
							["enabled"] = true,
							["texture"] = "1 Pixel",
							["color"] = {
								0.08627450980392157, -- [1]
								0.08627450980392157, -- [2]
								0.08627450980392157, -- [3]
								1, -- [4]
							},
							["size"] = 1,
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["textL_translit_text"] = false,
						["texture_custom_file"] = "Interface\\",
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["textR_bracket"] = "NONE",
						["font_size"] = 12,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes",
						["icon_grayscale"] = false,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["use_spec_icons"] = true,
						["textR_enable_custom_text"] = false,
						["textL_enable_custom_text"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Flat",
						["start_after_icon"] = true,
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["textR_class_colors"] = false,
						["alpha"] = 0,
						["textL_class_colors"] = false,
						["texture_background"] = "Details Flat",
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0, -- [4]
						},
						["font_face"] = "Arial Narrow",
						["texture_class_colors"] = true,
						["textL_outline_small"] = true,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["height"] = 20,
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["attribute_text"] = {
						["show_timer"] = {
							true, -- [1]
							true, -- [2]
							true, -- [3]
						},
						["shadow"] = true,
						["side"] = 1,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["custom_text"] = "{name}",
						["text_face"] = "Arial Narrow",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["enabled"] = false,
						["enable_custom_text"] = false,
						["text_size"] = 10,
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -437.0000580607663,
							["x"] = 748.5557199052892,
							["w"] = 209.5553960917103,
							["h"] = 85.99997579091723,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["ignore_mass_showhide"] = false,
					["plugins_grow_direction"] = 1,
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_damager"] = false,
					["show_sidebars"] = false,
					["skin_custom"] = "",
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
				}, -- [1]
			},
			["data_broker_text"] = "",
			["segments_amount"] = 18,
			["report_lines"] = 5,
			["clear_ungrouped"] = true,
			["use_battleground_server_parser"] = false,
			["skin"] = "WoW Interface",
			["override_spellids"] = true,
			["use_scroll"] = false,
			["report_schema"] = 1,
			["player_details_window"] = {
				["scale"] = 1,
				["skin"] = "ElvUI",
				["bar_texture"] = "Skyline",
			},
			["overall_clear_newboss"] = true,
			["minimum_combat_time"] = 5,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["ROGUE"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.25, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["UNKNOW"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PRIEST"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["PET"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["Alliance"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["Horde"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["SHAMAN"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["DRUID"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
			},
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["disable_alldisplays_window"] = false,
			["standard_skin"] = false,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["trash_auto_remove"] = true,
			["animation_speed_triggertravel"] = 5,
			["clear_graphic"] = true,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["ARENA_GREEN"] = {
					0.4, -- [1]
					1, -- [2]
					0.4, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["version"] = 1,
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
			},
			["segments_auto_erase"] = 2,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["hide"] = true,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["text_type"] = 1,
			},
			["instances_amount"] = 1,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["deny_score_messages"] = false,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["default_bg_color"] = 0.0941,
			["segments_amount_to_save"] = 18,
			["total_abbreviation"] = 2,
			["segments_panic_mode"] = false,
			["numerical_system_symbols"] = "auto",
			["overall_flag"] = 16,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["memory_threshold"] = 3,
			["overall_clear_logout"] = false,
			["numerical_system"] = 1,
			["force_activity_time_pvp"] = true,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["pvp_as_group"] = true,
			["disable_reset_button"] = false,
			["animate_scroll"] = false,
			["death_tooltip_width"] = 350,
			["time_type"] = 2,
			["default_bg_alpha"] = 0.5,
			["time_type_original"] = 2,
		},
	},
	["boss_mods_timers"] = {
		["encounter_timers_bw"] = {
		},
		["encounter_timers_dbm"] = {
		},
	},
	["spell_school_cache"] = {
		["Lava Burst"] = 4,
		["Fel Flames"] = 4,
		["Obliterate Off-Hand"] = 1,
		["Flame Shock"] = 4,
		["Crystal Shards"] = 8,
		["Corpo-a-Corpo"] = 1,
		["Death Strike"] = 1,
		["Howling Blast"] = 16,
		["Frost Strike Off-Hand"] = 16,
		["Meteor Slash"] = 4,
		["Unleash Flame"] = 4,
		["Obliterate"] = 1,
		["Shadow Word: Death"] = 32,
		["Searing Bolt"] = 4,
		["Frost Strike"] = 16,
		["Frost Fever"] = 16,
		["Razor Frost"] = 16,
		["Thrashing Charge"] = 1,
		["Log Smash"] = 1,
		["Bonk"] = 1,
		["Lightning Bolt"] = 8,
	},
	["deathlog_healingdone_min"] = 1,
	["plater"] = {
		["realtime_dps_enabled"] = false,
		["damage_taken_shadow"] = true,
		["realtime_dps_player_shadow"] = true,
		["damage_taken_enabled"] = false,
		["realtime_dps_player_size"] = 12,
		["damage_taken_size"] = 12,
		["realtime_dps_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["damage_taken_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_size"] = 12,
		["damage_taken_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_enabled"] = false,
		["realtime_dps_shadow"] = true,
	},
	["run_code"] = {
		["on_specchanged"] = "\n-- run when the player changes its spec",
		["on_zonechanged"] = "\n-- when the player changes zone, this code will run",
		["on_init"] = "\n-- code to run when Details! initializes, put here code which only will run once\n-- this also will run then the profile is changed\n\n--size of the death log tooltip in the Deaths display (default 350)\nDetails.death_tooltip_width = 350;\n\n--when in arena or battleground, details! silently switch to activity time (goes back to the old setting on leaving, default true)\nDetails.force_activity_time_pvp = true;\n\n--speed of the bar animations (default 33)\nDetails.animation_speed = 33;\n\n--threshold to trigger slow or fast speed (default 0.45)\nDetails.animation_speed_mintravel = 0.45;\n\n--call to update animations\nDetails:RefreshAnimationFunctions();\n\n--max window size, does require a /reload to work (default 480 x 450)\nDetails.max_window_size.width = 480;\nDetails.max_window_size.height = 450;\n\n--use the arena team color as the class color (default true)\nDetails.color_by_arena_team = true;\n\n--use the role icon in the player bar when inside an arena (default false)\nDetails.show_arena_role_icon = false;\n\n--how much time the update warning is shown (default 10)\nDetails.update_warning_timeout = 10;",
		["on_groupchange"] = "\n-- this code runs when the player enter or leave a group",
		["on_leavecombat"] = "\n-- this code runs when the player leave combat",
		["on_entercombat"] = "\n-- this code runs when the player enters in combat",
	},
	["spellid_ignored"] = {
	},
	["show_totalhitdamage_on_overkill"] = false,
	["createauraframe"] = {
	},
	["global_plugin_database"] = {
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["encounter_timers_bw"] = {
			},
			["encounter_timers_dbm"] = {
			},
		},
	},
	["always_use_profile"] = false,
	["savedCustomSpells"] = {
		{
			49184, -- [1]
			"Howling Blast (Main Target)", -- [2]
			"Interface\\Icons\\Spell_Frost_ArcticWinds", -- [3]
		}, -- [1]
		{
			7, -- [1]
			"Environment (Lava)", -- [2]
			"Interface\\ICONS\\Ability_Rhyolith_Volcano", -- [3]
		}, -- [2]
		{
			1, -- [1]
			"Melee", -- [2]
			"Interface\\ICONS\\INV_Sword_04", -- [3]
		}, -- [3]
		{
			2, -- [1]
			"Auto Shot", -- [2]
			"Interface\\ICONS\\INV_Weapon_Bow_07", -- [3]
		}, -- [4]
		{
			4, -- [1]
			"Environment (Drowning)", -- [2]
			"Interface\\ICONS\\Ability_Suffocate", -- [3]
		}, -- [5]
		{
			8, -- [1]
			"Environment (Slime)", -- [2]
			"Interface\\ICONS\\Ability_Creature_Poison_02", -- [3]
		}, -- [6]
		{
			55090, -- [1]
			"Scourge Strike (Physical)", -- [2]
			"Interface\\Icons\\Spell_DeathKnight_ScourgeStrike", -- [3]
		}, -- [7]
		{
			5, -- [1]
			"Environment (Fatigue)", -- [2]
			"Interface\\ICONS\\Spell_Arcane_MindMastery", -- [3]
		}, -- [8]
		{
			70890, -- [1]
			"Scourge Strike (Shadow)", -- [2]
			"Interface\\Icons\\Spell_Shadow_ShadowBolt", -- [3]
		}, -- [9]
		{
			33778, -- [1]
			"Lifebloom (Bloom)", -- [2]
			"Interface\\Icons\\Spell_Nature_HealingTouch", -- [3]
		}, -- [10]
		{
			3, -- [1]
			"Environment (Falling)", -- [2]
			"Interface\\ICONS\\Spell_Magic_FeatherFall", -- [3]
		}, -- [11]
		{
			6, -- [1]
			"Environment (Fire)", -- [2]
			"Interface\\ICONS\\INV_SummerFest_FireSpirit", -- [3]
		}, -- [12]
		{
			44461, -- [1]
			"Living Bomb (explosion)", -- [2]
			"Interface\\Icons\\Ability_Mage_LivingBomb", -- [3]
		}, -- [13]
		{
			59638, -- [1]
			"Frostbolt (Mirror Image)", -- [2]
			"Interface\\Icons\\Spell_Frost_FrostBolt02", -- [3]
		}, -- [14]
	},
	["report_where"] = "SAY",
	["switchSaved"] = {
		["slots"] = 8,
		["table"] = {
			{
				["atributo"] = 1,
				["sub_atributo"] = 1,
			}, -- [1]
			{
				["atributo"] = 2,
				["sub_atributo"] = 1,
			}, -- [2]
			{
				["atributo"] = 1,
				["sub_atributo"] = 6,
			}, -- [3]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [4]
			{
			}, -- [5]
			{
			}, -- [6]
			{
			}, -- [7]
			{
			}, -- [8]
			{
			}, -- [9]
			{
			}, -- [10]
			{
			}, -- [11]
			{
			}, -- [12]
			{
			}, -- [13]
			{
			}, -- [14]
		},
	},
	["raid_data"] = {
		[2] = {
			[47120] = {
				["longest"] = 345.2199999999721,
				["kills"] = 0,
				["try_history"] = {
					{
						0.1880910911377078, -- [1]
						345.2199999999721, -- [2]
					}, -- [1]
					{
						0.002749483847933063, -- [1]
						279.2470000002068, -- [2]
					}, -- [2]
				},
				["wipes"] = 5,
				["best_try"] = 0.002749483847933063,
			},
		},
	},
	["tutorial"] = {
		["unlock_button"] = 0,
		["main_help_button"] = 225,
		["alert_frames"] = {
			false, -- [1]
			false, -- [2]
			false, -- [3]
			false, -- [4]
			false, -- [5]
			false, -- [6]
		},
		["bookmark_tutorial"] = false,
		["MIN_COMBAT_TIME"] = true,
		["logons"] = 225,
		["version_announce"] = 0,
		["DETAILS_INFO_TUTORIAL2"] = 10,
		["ctrl_click_close_tutorial"] = false,
		["DISABLE_ONDEATH_PANEL"] = true,
		["ATTRIBUTE_SELECT_TUTORIAL1"] = true,
	},
	["always_use_profile_name"] = "",
	["savedStyles"] = {
	},
	["always_use_profile_exception"] = {
	},
	["details_auras"] = {
	},
	["plugin_window_pos"] = {
		["y"] = 0,
		["x"] = 5.252139976619219e-005,
		["point"] = "CENTER",
		["scale"] = 1,
	},
	["savedTimeCaptures"] = {
		{
			"Player Damage Done", -- [1]
			"\n	-- the goal of this script is get the current combat then get your character and extract your damage done.\n	-- the first thing to do is get the combat, so, we use here the command \"_detalhes:GetCombat ( \"overall\" \"current\" or \"segment number\")\"\n\n	local current_combat = _detalhes:GetCombat (\"current\") --> getting the current combat\n\n	-- the next step is request your character from the combat\n	-- to do this, we take the combat which here we named \"current_combat\" and tells what we want inside parentheses.\n\n	local my_self = current_combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n\n	-- _detalhes.playername holds the name of your character.\n	-- DETAILS_ATTRIBUTE_DAMAGE means we want the damage table, _HEAL _ENERGY _MISC is the other 3 tables.\n\n	-- before we proceed, the result needs to be checked to make sure its a valid result.\n\n	if (not my_self) then\n		return 0 -- the combat doesnt have *you*, this happens when you didn't deal any damage in the combat yet.\n	end\n\n	-- now its time to get the total damage.\n\n	local my_damage = my_self.total\n\n	-- then finally return the amount to the capture.\n\n	return my_damage\n\n", -- [2]
			{
				["max_value"] = 0,
				["last_value"] = 0,
			}, -- [3]
			"Chart Viewer", -- [4]
			"1.0", -- [5]
			"Interface\\ICONS\\Ability_MeleeDamage", -- [6]
			true, -- [7]
		}, -- [1]
	},
	["latest_news_saw"] = "",
	["custom"] = {
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show who in your raid used a potion during the encounter.",
			["tooltip"] = "		--init:\n		local player, combat, instance = ...\n\n		--get the debuff container for potion of focus\n		local debuff_uptime_container = player.debuff_uptime and player.debuff_uptime_spells and player.debuff_uptime_spells._ActorTable\n		if(debuff_uptime_container) then\n			local focus_potion = debuff_uptime_container[DETAILS_FOCUS_POTION_ID]\n			if(focus_potion) then\n			local name, _, icon = GetSpellInfo(DETAILS_FOCUS_POTION_ID)\n			GameCooltip:AddLine(name, 1) --> can use only 1 focus potion(can't be pre-potion)\n			_detalhes:AddTooltipBackgroundStatusbar()\n			GameCooltip:AddIcon(icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			end\n		end\n\n		--get the misc actor container\n		local buff_uptime_container = player.buff_uptime and player.buff_uptime_spells and player.buff_uptime_spells._ActorTable\n		if(buff_uptime_container) then\n			for spellId, _ in pairs(DetailsFramework.PotionIDs) do\n				local potionUsed = buff_uptime_container[spellId]\n\n				if(potionUsed) then\n					local name, _, icon = GetSpellInfo(spellId)\n					GameCooltip:AddLine(name, potionUsed.activedamt)\n					_detalhes:AddTooltipBackgroundStatusbar()\n					GameCooltip:AddIcon(icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n			end\n		end\n		",
			["attribute"] = false,
			["name"] = "Potion Used",
			["script"] = "			--init:\n			local combat, instance_container, instance = ...\n			local total, top, amount = 0, 0, 0\n\n			--get the misc actor container\n			local misc_container = combat:GetActorList( DETAILS_ATTRIBUTE_MISC )\n\n			--do the loop:\n			for _, player in ipairs( misc_container ) do\n\n				--only player in group\n				if(player:IsGroupPlayer()) then\n\n					local found_potion = false\n\n					--get the spell debuff uptime container\n					local debuff_uptime_container = player.debuff_uptime and player.debuff_uptime_spells and player.debuff_uptime_spells._ActorTable\n					if(debuff_uptime_container) then\n						--potion of focus(can't use as pre-potion, so, its amount is always 1\n						local focus_potion = debuff_uptime_container[DETAILS_FOCUS_POTION_ID]\n\n						if(focus_potion) then\n							total = total + 1\n							found_potion = true\n							if(top < 1) then\n								top = 1\n							end\n							--add amount to the player\n							instance_container:AddValue(player, 1)\n						end\n					end\n\n					--get the spell buff uptime container\n					local buff_uptime_container = player.buff_uptime and player.buff_uptime_spells and player.buff_uptime_spells._ActorTable\n					if(buff_uptime_container) then\n						for spellId, _ in pairs(DetailsFramework.PotionIDs) do\n							local potionUsed = buff_uptime_container[spellId]\n\n							if(potionUsed) then\n								local used = potionUsed.activedamt\n								if(used and used > 0) then\n									total = total + used\n									found_potion = true\n									if(used > top) then\n										top = used\n									end\n\n									--add amount to the player\n									instance_container:AddValue(player, used)\n								end\n							end\n						end\n					end\n\n					if(found_potion) then\n						amount = amount + 1\n					end\n				end\n			end\n\n			--return:\n			return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\INV_Potion_03",
			["script_version"] = 6,
		}, -- [1]
		{
			["source"] = false,
			["desc"] = "Show who in your raid group used the healthstone or a heal potion.",
			["author"] = "Details! Team",
			["percent_script"] = false,
			["total_script"] = false,
			["attribute"] = false,
			["tooltip"] = "		--get the parameters passed\n		local actor, combat, instance = ...\n\n		--get the cooltip object(we dont use the convencional GameTooltip here)\n		local GameCooltip = GameCooltip\n		local R, G, B, A = 0, 0, 0, 0.75\n\n		local hs = actor:GetSpell(6262)\n		if(hs) then\n			GameCooltip:AddLine(select(1, GetSpellInfo(6262)),  _detalhes:ToK(hs.total))\n			GameCooltip:AddIcon(select(3, GetSpellInfo(6262)), 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			GameCooltip:AddStatusBar(100, 1, R, G, B, A)\n		end\n\n		local pot = actor:GetSpell(DETAILS_HEALTH_POTION_ID)\n		if(pot) then\n			GameCooltip:AddLine(select(1, GetSpellInfo(DETAILS_HEALTH_POTION_ID)),  _detalhes:ToK(pot.total))\n			GameCooltip:AddIcon(select(3, GetSpellInfo(DETAILS_HEALTH_POTION_ID)), 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			GameCooltip:AddStatusBar(100, 1, R, G, B, A)\n		end\n\n		local pot = actor:GetSpell(DETAILS_REJU_POTION_ID)\n		if(pot) then\n			GameCooltip:AddLine(select(1, GetSpellInfo(DETAILS_REJU_POTION_ID)),  _detalhes:ToK(pot.total))\n			GameCooltip:AddIcon(select(3, GetSpellInfo(DETAILS_REJU_POTION_ID)), 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			GameCooltip:AddStatusBar(100, 1, R, G, B, A)\n		end\n\n		--Cooltip code\n		",
			["name"] = "Health Potion & Stone",
			["script"] = "		--get the parameters passed\n		local combat, instance_container, instance = ...\n		--declade the values to return\n		local total, top, amount = 0, 0, 0\n\n		--do the loop\n		local AllHealCharacters = combat:GetActorList(DETAILS_ATTRIBUTE_HEAL)\n		for index, character in ipairs(AllHealCharacters) do\n			local AllSpells = character:GetSpellList()\n			local found = false\n			for spellid, spell in pairs(AllSpells) do\n				if(DETAILS_HEALTH_POTION_LIST[spellid]) then\n					instance_container:AddValue(character, spell.total)\n					total = total + spell.total\n					if(top < spell.total) then\n						top = spell.total\n					end\n					found = true\n				end\n			end\n\n			if(found) then\n				amount = amount + 1\n			end\n		end\n		--loop end\n		--return the values\n		return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\INV_Stone_04",
			["script_version"] = 15,
		}, -- [2]
		{
			["source"] = false,
			["tooltip"] = "\n		",
			["author"] = "Details!",
			["percent_script"] = "			local value, top, total, combat, instance = ...\n			return string.format(\"%.1f\", value/top*100)\n		",
			["desc"] = "Tells how much time each character spent doing damage.",
			["attribute"] = false,
			["total_script"] = "			local value, top, total, combat, instance = ...\n			local minutos, segundos = math.floor(value/60), math.floor(value%60)\n			return minutos .. \"m \" .. segundos .. \"s\"\n		",
			["name"] = "Damage Activity Time",
			["script"] = "			--init:\n			local combat, instance_container, instance = ...\n			local total, amount = 0, 0\n\n			--get the misc actor container\n			local damage_container = combat:GetActorList( DETAILS_ATTRIBUTE_DAMAGE )\n\n			--do the loop:\n			for _, player in ipairs( damage_container ) do\n				if(player.grupo) then\n					local activity = player:Tempo()\n					total = total + activity\n					amount = amount + 1\n					--add amount to the player\n					instance_container:AddValue(player, activity)\n				end\n			end\n\n			--return:\n			return total, combat:GetCombatTime(), amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Red",
			["script_version"] = 3,
		}, -- [3]
		{
			["source"] = false,
			["tooltip"] = "\n		",
			["author"] = "Details!",
			["percent_script"] = "			local value, top, total, combat, instance = ...\n			return string.format(\"%.1f\", value/top*100)\n		",
			["desc"] = "Tells how much time each character spent doing healing.",
			["attribute"] = false,
			["total_script"] = "			local value, top, total, combat, instance = ...\n			local minutos, segundos = math.floor(value/60), math.floor(value%60)\n			return minutos .. \"m \" .. segundos .. \"s\"\n		",
			["name"] = "Healing Activity Time",
			["script"] = "			--init:\n			local combat, instance_container, instance = ...\n			local total, top, amount = 0, 0, 0\n\n			--get the misc actor container\n			local damage_container = combat:GetActorList( DETAILS_ATTRIBUTE_HEAL )\n\n			--do the loop:\n			for _, player in ipairs( damage_container ) do\n				if(player.grupo) then\n					local activity = player:Tempo()\n					total = total + activity\n					amount = amount + 1\n					--add amount to the player\n					instance_container:AddValue(player, activity)\n				end\n			end\n\n			--return:\n			return total, combat:GetCombatTime(), amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Green",
			["script_version"] = 2,
		}, -- [4]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "			local value, top, total, combat, instance = ...\n			return floor(value)\n		",
			["desc"] = "Show the crowd control amount for each player.",
			["attribute"] = false,
			["script"] = "			local combat, instance_container, instance = ...\n			local total, top, amount = 0, 0, 0\n\n			local misc_actors = combat:GetActorList(DETAILS_ATTRIBUTE_MISC)\n\n			for index, character in ipairs(misc_actors) do\n				if(character.cc_done and character:IsPlayer()) then\n					local cc_done = floor(character.cc_done)\n					instance_container:AddValue(character, cc_done)\n					total = total + cc_done\n					if(cc_done > top) then\n						top = cc_done\n					end\n					amount = amount + 1\n				end\n			end\n\n			return total, top, amount\n		",
			["name"] = "Crowd Control Done",
			["tooltip"] = "			local actor, combat, instance = ...\n			local spells = {}\n			for spellid, spell in pairs(actor.cc_done_spells._ActorTable) do\n				tinsert(spells, {spellid, spell.counter})\n			end\n\n			table.sort(spells, _detalhes.Sort2)\n\n			for index, spell in ipairs(spells) do\n				local name, _, icon = GetSpellInfo(spell[1])\n				GameCooltip:AddLine(name, spell[2])\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon(icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			end\n\n			local targets = {}\n			for playername, amount in pairs(actor.cc_done_targets) do\n				tinsert(targets, {playername, amount})\n			end\n\n			table.sort(targets, _detalhes.Sort2)\n\n			_detalhes:AddTooltipSpellHeaderText(\"Targets\", \"yellow\", #targets)\n			local class, _, _, _, _, r, g, b = _detalhes:GetClass(actor.nome)\n			_detalhes:AddTooltipHeaderStatusbar(1, 1, 1, 0.6)\n\n			for index, target in ipairs(targets) do\n				GameCooltip:AddLine(target[1], target[2])\n				_detalhes:AddTooltipBackgroundStatusbar()\n\n				local class, _, _, _, _, r, g, b = _detalhes:GetClass(target[1])\n				if(class and class ~= \"UNKNOW\") then\n				local texture, l, r, t, b = _detalhes:GetClassIcon(class)\n				GameCooltip:AddIcon(\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				else\n				GameCooltip:AddIcon(\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n				--\n			end\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Frost_FreezingBreath",
			["script_version"] = 11,
		}, -- [5]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "			local value, top, total, combat, instance = ...\n			return floor(value)\n		",
			["desc"] = "Show the amount of crowd control received for each player.",
			["attribute"] = false,
			["script"] = "			local combat, instance_container, instance = ...\n			local total, top, amt = 0, 0, 0\n\n			local misc_actors = combat:GetActorList(DETAILS_ATTRIBUTE_MISC)\n			DETAILS_CUSTOM_CC_RECEIVED_CACHE = DETAILS_CUSTOM_CC_RECEIVED_CACHE or {}\n			wipe(DETAILS_CUSTOM_CC_RECEIVED_CACHE)\n\n			for index, character in ipairs(misc_actors) do\n				if(character.cc_done and character:IsPlayer()) then\n\n				for player_name, amount in pairs(character.cc_done_targets) do\n					local target = combat(1, player_name) or combat(2, player_name)\n					if(target and target:IsPlayer()) then\n					instance_container:AddValue(target, amount)\n					total = total + amount\n					if(amount > top) then\n						top = amount\n					end\n					if(not DETAILS_CUSTOM_CC_RECEIVED_CACHE[player_name]) then\n						DETAILS_CUSTOM_CC_RECEIVED_CACHE[player_name] = true\n						amt = amt + 1\n					end\n					end\n				end\n\n				end\n			end\n\n			return total, top, amt\n		",
			["name"] = "Crowd Control Received",
			["tooltip"] = "			local actor, combat, instance = ...\n			local name = actor:name()\n			local spells, from = {}, {}\n			local misc_actors = combat:GetActorList(DETAILS_ATTRIBUTE_MISC)\n\n			for index, character in ipairs(misc_actors) do\n				if(character.cc_done and character:IsPlayer()) then\n				local on_actor = character.cc_done_targets[name]\n				if(on_actor) then\n					tinsert(from, {character:name(), on_actor})\n\n					for spellid, spell in pairs(character.cc_done_spells._ActorTable) do\n\n					local spell_on_actor = spell.targets[name]\n					if(spell_on_actor) then\n						local has_spell\n						for index, spell_table in ipairs(spells) do\n						if(spell_table[1] == spellid) then\n							spell_table[2] = spell_table[2] + spell_on_actor\n							has_spell = true\n						end\n						end\n						if(not has_spell) then\n						tinsert(spells, {spellid, spell_on_actor})\n						end\n					end\n\n					end\n				end\n				end\n			end\n\n			table.sort(from, _detalhes.Sort2)\n			table.sort(spells, _detalhes.Sort2)\n\n			for index, spell in ipairs(spells) do\n				local name, _, icon = GetSpellInfo(spell[1])\n				GameCooltip:AddLine(name, spell[2])\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon(icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n			end\n\n			_detalhes:AddTooltipSpellHeaderText(\"From\", \"yellow\", #from)\n			_detalhes:AddTooltipHeaderStatusbar(1, 1, 1, 0.6)\n\n			for index, t in ipairs(from) do\n				GameCooltip:AddLine(t[1], t[2])\n				_detalhes:AddTooltipBackgroundStatusbar()\n\n				local class, _, _, _, _, r, g, b = _detalhes:GetClass(t[1])\n				if(class and class ~= \"UNKNOW\") then\n				local texture, l, r, t, b = _detalhes:GetClassIcon(class)\n				GameCooltip:AddIcon(\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				else\n				GameCooltip:AddIcon(\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n\n			end\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Frost_ChainsOfIce",
			["script_version"] = 3,
		}, -- [6]
		{
			["source"] = false,
			["author"] = "Details!",
			["percent_script"] = "			local value, top, total, combat, instance = ...\n			local dps = _detalhes:ToK(floor(value) / combat:GetCombatTime())\n			local percent = string.format(\"%.1f\", value/total*100)\n			return dps .. \", \" .. percent\n		",
			["desc"] = "Show your spells in the window.",
			["tooltip"] = "		--config:\n		--Background RBG and Alpha:\n		local R, G, B, A = 0, 0, 0, 0.75\n		local R, G, B, A = 0.1960, 0.1960, 0.1960, 0.8697\n\n		--get the parameters passed\n		local spell, combat, instance = ...\n\n		--get the cooltip object(we dont use the convencional GameTooltip here)\n		local GC = GameCooltip\n		GC:SetOption(\"YSpacingMod\", 0)\n\n		local role = DetailsFramework.UnitGroupRolesAssigned(\"player\")\n\n		if(spell.n_dmg) then\n\n			local spellschool, schooltext = spell.spellschool, \"\"\n			if(spellschool) then\n			local t = _detalhes.spells_school[spellschool]\n			if(t and t.name) then\n				schooltext = t.formated\n			end\n			end\n\n			local total_hits = spell.counter\n			local combat_time = instance.showing:GetCombatTime()\n\n			local debuff_uptime_total, cast_string = \"\", \"\"\n			local misc_actor = instance.showing(4, _detalhes.playername)\n			if(misc_actor) then\n			local debuff_uptime = misc_actor.debuff_uptime_spells and misc_actor.debuff_uptime_spells._ActorTable[spell.id] and misc_actor.debuff_uptime_spells._ActorTable[spell.id].uptime\n			if(debuff_uptime) then\n				debuff_uptime_total = floor(debuff_uptime / instance.showing:GetCombatTime() * 100)\n			end\n\n			local spell_cast = misc_actor.spell_cast and misc_actor.spell_cast[spell.id]\n\n			if(not spell_cast and misc_actor.spell_cast) then\n				local spellname = GetSpellInfo(spell.id)\n				for casted_spellid, amount in pairs(misc_actor.spell_cast) do\n				local casted_spellname = GetSpellInfo(casted_spellid)\n				if(casted_spellname == spellname) then\n					spell_cast = amount .. \"(|cFFFFFF00?|r)\"\n				end\n				end\n			end\n			if(not spell_cast) then\n				spell_cast = \"(|cFFFFFF00?|r)\"\n			end\n			cast_string = cast_string .. spell_cast\n			end\n\n			--Cooltip code\n			GC:AddLine(\"Casts:\", cast_string or \"?\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			if(debuff_uptime_total ~= \"\") then\n			GC:AddLine(\"Uptime:\",(debuff_uptime_total or \"?\") .. \"%\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n			end\n\n			GC:AddLine(\"Hits:\", spell.counter)\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			local average = spell.total / total_hits\n			GC:AddLine(\"Average:\", _detalhes:ToK(average))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			GC:AddLine(\"E-Dps:\", _detalhes:ToK(spell.total / combat_time))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			GC:AddLine(\"School:\", schooltext)\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			GC:AddLine(\"Normal Hits: \", spell.n_amt .. \"(\" ..floor( spell.n_amt/total_hits*100) .. \"%)\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			local n_average = spell.n_dmg / spell.n_amt\n			local T =(combat_time*spell.n_dmg)/spell.total\n			local P = average/n_average*100\n			T = P*T/100\n\n			GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK(n_average) .. \" / \" .. format(\"%.1f\",spell.n_dmg / T ))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			GC:AddLine(\"Critical Hits: \", spell.c_amt .. \"(\" ..floor( spell.c_amt/total_hits*100) .. \"%)\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			if(spell.c_amt > 0) then\n			local c_average = spell.c_dmg/spell.c_amt\n			local T =(combat_time*spell.c_dmg)/spell.total\n			local P = average/c_average*100\n			T = P*T/100\n			local crit_dps = spell.c_dmg / T\n\n			GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK(c_average) .. \" / \" .. _detalhes:comma_value(crit_dps))\n			else\n			GC:AddLine(\"Average / E-Dps: \",  \"0 / 0\")\n			end\n\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			--GC:AddLine(\"Multistrike: \", spell.m_amt .. \"(\" ..floor( spell.m_amt/total_hits*100) .. \"%)\")\n			--GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\"On Normal / On Critical:\", spell.m_amt - spell.m_crit .. \"  / \" .. spell.m_crit)\n			--GC:AddStatusBar(100, 1, R, G, B, A)\n\n		elseif(spell.n_curado) then\n\n			local spellschool, schooltext = spell.spellschool, \"\"\n			if(spellschool) then\n			local t = _detalhes.spells_school[spellschool]\n			if(t and t.name) then\n				schooltext = t.formated\n			end\n			end\n\n			local total_hits = spell.counter\n			local combat_time = instance.showing:GetCombatTime()\n\n			--Cooltip code\n			GC:AddLine(\"Hits:\", spell.counter)\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			local average = spell.total / total_hits\n			GC:AddLine(\"Average:\", _detalhes:ToK(average))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			GC:AddLine(\"E-Hps:\", _detalhes:ToK(spell.total / combat_time))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			GC:AddLine(\"School:\", schooltext)\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			GC:AddLine(\"Normal Hits: \", spell.n_amt .. \"(\" ..floor( spell.n_amt/total_hits*100) .. \"%)\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			local n_average = spell.n_curado / spell.n_amt\n			local T =(combat_time*spell.n_curado)/spell.total\n			local P = average/n_average*100\n			T = P*T/100\n\n			GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK(n_average) .. \" / \" .. format(\"%.1f\",spell.n_curado / T ))\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			GC:AddLine(\"Critical Hits: \", spell.c_amt .. \"(\" ..floor( spell.c_amt/total_hits*100) .. \"%)\")\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			if(spell.c_amt > 0) then\n			local c_average = spell.c_curado/spell.c_amt\n			local T =(combat_time*spell.c_curado)/spell.total\n			local P = average/c_average*100\n			T = P*T/100\n			local crit_dps = spell.c_curado / T\n\n			GC:AddLine(\"Average / E-Hps: \",  _detalhes:ToK(c_average) .. \" / \" .. _detalhes:comma_value(crit_dps))\n			else\n			GC:AddLine(\"Average / E-Hps: \",  \"0 / 0\")\n			end\n\n			GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\" \")\n\n			--GC:AddLine(\"Multistrike: \", spell.m_amt .. \"(\" ..floor( spell.m_amt/total_hits*100) .. \"%)\")\n			--GC:AddStatusBar(100, 1, R, G, B, A)\n\n			--GC:AddLine(\"On Normal / On Critical:\", spell.m_amt - spell.m_crit .. \"  / \" .. spell.m_crit)\n			--GC:AddStatusBar(100, 1, R, G, B, A)\n		end\n		",
			["attribute"] = false,
			["name"] = "My Spells",
			["script"] = "			--get the parameters passed\n			local combat, instance_container, instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n\n			local player\n			local pet_attribute\n\n			local role = DetailsFramework.UnitGroupRolesAssigned(\"player\")\n			local spec = DetailsFramework.GetSpecialization()\n			role = spec and DetailsFramework.GetSpecializationRole(spec) or role\n\n			if(role == \"DAMAGER\") then\n				player = combat(DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n				pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n			elseif(role == \"HEALER\") then\n				player = combat(DETAILS_ATTRIBUTE_HEAL, _detalhes.playername)\n				pet_attribute = DETAILS_ATTRIBUTE_HEAL\n			else\n				player = combat(DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n				pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n			end\n\n			--do the loop\n\n			if(player) then\n				local spells = player:GetSpellList()\n				for spellid, spell in pairs(spells) do\n					instance_container:AddValue(spell, spell.total)\n					total = total + spell.total\n					if(top < spell.total) then\n						top = spell.total\n					end\n					amount = amount + 1\n				end\n\n				for _, PetName in ipairs(player.pets) do\n					local pet = combat(pet_attribute, PetName)\n					if(pet) then\n						for spellid, spell in pairs(pet:GetSpellList()) do\n							instance_container:AddValue(spell, spell.total, nil, \"(\" .. PetName:gsub((\" <.*\"), \"\") .. \")\")\n							total = total + spell.total\n							if(top < spell.total) then\n								top = spell.total\n							end\n							amount = amount + 1\n						end\n					end\n				end\n			end\n\n			--return the values\n			return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\CHATFRAME\\UI-ChatIcon-WoW",
			["script_version"] = 7,
		}, -- [7]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with skull.",
			["tooltip"] = "			--get the parameters passed\n			local actor, combat, instance = ...\n\n			--get the cooltip object(we dont use the convencional GameTooltip here)\n			local GameCooltip = GameCooltip\n\n			--Cooltip code\n			local format_func = Details:GetCurrentToKFunction()\n\n			--Cooltip code\n			local RaidTargets = actor.raid_targets\n\n			local DamageOnStar = RaidTargets[128]\n			if(DamageOnStar) then\n				--RAID_TARGET_8 is the built-in localized word for 'Skull'.\n				GameCooltip:AddLine(RAID_TARGET_8 .. \":\", format_func(_, DamageOnStar))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_8\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n		",
			["attribute"] = false,
			["name"] = "Damage On Skull Marked Targets",
			["script"] = "			--get the parameters passed\n			local Combat, CustomContainer, Instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n\n			--raid target flags:\n			-- 128: skull\n			-- 64: cross\n			-- 32: square\n			-- 16: moon\n			-- 8: triangle\n			-- 4: diamond\n			-- 2: circle\n			-- 1: star\n\n			--do the loop\n			for _, actor in ipairs(Combat:GetActorList(DETAILS_ATTRIBUTE_DAMAGE)) do\n				if(actor:IsPlayer()) then\n				if(actor.raid_targets[128]) then\n					CustomContainer:AddValue(actor, actor.raid_targets[128])\n				end\n				end\n			end\n\n			--if not managed inside the loop, get the values of total, top and amount\n			total, top = CustomContainer:GetTotalAndHighestValue()\n			amount = CustomContainer:GetNumActors()\n\n			--return the values\n			return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_8",
			["script_version"] = 3,
		}, -- [8]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with any other mark.",
			["tooltip"] = "			--get the parameters passed\n			local actor, combat, instance = ...\n\n			--get the cooltip object\n			local GameCooltip = GameCooltip\n\n			local format_func = Details:GetCurrentToKFunction()\n\n			--Cooltip code\n			local RaidTargets = actor.raid_targets\n\n			local DamageOnStar = RaidTargets[1]\n			if(DamageOnStar) then\n				GameCooltip:AddLine(RAID_TARGET_1 .. \":\", format_func(_, DamageOnStar))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_1\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnCircle = RaidTargets[2]\n			if(DamageOnCircle) then\n				GameCooltip:AddLine(RAID_TARGET_2 .. \":\", format_func(_, DamageOnCircle))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_2\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnDiamond = RaidTargets[4]\n			if(DamageOnDiamond) then\n				GameCooltip:AddLine(RAID_TARGET_3 .. \":\", format_func(_, DamageOnDiamond))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_3\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnTriangle = RaidTargets[8]\n			if(DamageOnTriangle) then\n				GameCooltip:AddLine(RAID_TARGET_4 .. \":\", format_func(_, DamageOnTriangle))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_4\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnMoon = RaidTargets[16]\n			if(DamageOnMoon) then\n				GameCooltip:AddLine(RAID_TARGET_5 .. \":\", format_func(_, DamageOnMoon))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_5\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnSquare = RaidTargets[32]\n			if(DamageOnSquare) then\n				GameCooltip:AddLine(RAID_TARGET_6 .. \":\", format_func(_, DamageOnSquare))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_6\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n\n			local DamageOnCross = RaidTargets[64]\n			if(DamageOnCross) then\n				GameCooltip:AddLine(RAID_TARGET_7 .. \":\", format_func(_, DamageOnCross))\n				GameCooltip:AddIcon(\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_7\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				Details:AddTooltipBackgroundStatusbar()\n			end\n		",
			["attribute"] = false,
			["name"] = "Damage On Other Marked Targets",
			["script"] = "			--get the parameters passed\n			local Combat, CustomContainer, Instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n\n			--do the loop\n			for _, actor in ipairs(Combat:GetActorList(DETAILS_ATTRIBUTE_DAMAGE)) do\n				if(actor:IsPlayer()) then\n				local total =(actor.raid_targets[1] or 0) --star\n				total = total +(actor.raid_targets[2] or 0) --circle\n				total = total +(actor.raid_targets[4] or 0) --diamond\n				total = total +(actor.raid_targets[8] or 0) --tiangle\n				total = total +(actor.raid_targets[16] or 0) --moon\n				total = total +(actor.raid_targets[32] or 0) --square\n				total = total +(actor.raid_targets[64] or 0) --cross\n\n				if(total > 0) then\n					CustomContainer:AddValue(actor, total)\n				end\n				end\n			end\n\n			--if not managed inside the loop, get the values of total, top and amount\n			total, top = CustomContainer:GetTotalAndHighestValue()\n			amount = CustomContainer:GetNumActors()\n\n			--return the values\n			return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_5",
			["script_version"] = 3,
		}, -- [9]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "			local value, top, total, combat, instance = ...\n\n			--get the time of overall combat\n			local OverallCombatTime = Details:GetCombat(-1):GetCombatTime()\n\n			--get the time of current combat if the player is in combat\n			if(Details.in_combat) then\n				local CurrentCombatTime = Details:GetCombat(0):GetCombatTime()\n				OverallCombatTime = OverallCombatTime + CurrentCombatTime\n			end\n\n			--build the string\n			local ToK = Details:GetCurrentToKFunction()\n			local s = ToK(_, value / OverallCombatTime)\n\n			if(instance.row_info.textR_show_data[3]) then\n				s = ToK(_, value) .. \"(\" .. s .. \", \"\n			else\n				s = ToK(_, value) .. \"(\" .. s\n			end\n\n			return s\n		",
			["desc"] = "Show overall damage done on the fly.",
			["attribute"] = false,
			["script"] = "			--init:\n			local combat, instance_container, instance = ...\n			local total, top, amount = 0, 0, 0\n\n			--get the overall combat\n			local OverallCombat = Details:GetCombat(-1)\n			--get the current combat\n			local CurrentCombat = Details:GetCombat(0)\n\n			if(not OverallCombat.GetActorList or not CurrentCombat.GetActorList) then\n				return 0, 0, 0\n			end\n\n			--get the damage actor container for overall\n			local damage_container_overall = OverallCombat:GetActorList( DETAILS_ATTRIBUTE_DAMAGE )\n			--get the damage actor container for current\n			local damage_container_current = CurrentCombat:GetActorList( DETAILS_ATTRIBUTE_DAMAGE )\n\n			--do the loop:\n			for _, player in ipairs( damage_container_overall ) do\n				--only player in group\n				if(player:IsGroupPlayer()) then\n				instance_container:AddValue(player, player.total)\n				end\n			end\n\n			if(Details.in_combat) then\n				for _, player in ipairs( damage_container_current ) do\n				--only player in group\n				if(player:IsGroupPlayer()) then\n					instance_container:AddValue(player, player.total)\n				end\n				end\n			end\n\n			total, top =  instance_container:GetTotalAndHighestValue()\n			amount =  instance_container:GetNumActors()\n\n			--return:\n			return total, top, amount\n		",
			["name"] = "Dynamic Overall Damage",
			["tooltip"] = "			--get the parameters passed\n			local actor, combat, instance = ...\n\n			--get the cooltip object(we dont use the convencional GameTooltip here)\n			local GameCooltip = GameCooltip2\n\n			--Cooltip code\n			--get the overall combat\n			local OverallCombat = Details:GetCombat(-1)\n			--get the current combat\n			local CurrentCombat = Details:GetCombat(0)\n\n			local AllSpells = {}\n\n			--overall\n			local player = OverallCombat[1]:GetActor(actor.nome)\n			local playerSpells = player:GetSpellList()\n			for spellID, spellTable in pairs(playerSpells) do\n				AllSpells[spellID] = spellTable.total\n			end\n\n			--current\n			local player = CurrentCombat[1]:GetActor(actor.nome)\n			if(player) then\n				local playerSpells = player:GetSpellList()\n				for spellID, spellTable in pairs(playerSpells) do\n					AllSpells[spellID] =(AllSpells[spellID] or 0) +(spellTable.total or 0)\n				end\n			end\n\n			local sortedList = {}\n			for spellID, total in pairs(AllSpells) do\n				tinsert(sortedList, {spellID, total})\n			end\n			table.sort(sortedList, Details.Sort2)\n\n			local format_func = Details:GetCurrentToKFunction()\n\n			--build the tooltip\n			for i, t in ipairs(sortedList) do\n				local spellID, total = unpack(t)\n				if(total > 1) then\n				local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n\n				GameCooltip:AddLine(spellName, format_func(_, total))\n				Details:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon(spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n			end\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\Spell-Reset",
			["script_version"] = 5,
		}, -- [10]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Damage done to shields",
			["tooltip"] = "			--get the parameters passed\n			local actor, Combat, instance = ...\n\n			--get the cooltip object(we dont use the convencional GameTooltip here)\n			local GameCooltip = GameCooltip\n\n			--Cooltip code\n			--get the actor total damage absorbed\n			local totalAbsorb = actor.totalabsorbed\n			local format_func = Details:GetCurrentToKFunction()\n\n			--get the damage absorbed by all the actor pets\n			for petIndex, petName in ipairs(actor.pets) do\n				local pet = Combat :GetActor(1, petName)\n				if(pet) then\n				totalAbsorb = totalAbsorb + pet.totalabsorbed\n				end\n			end\n\n			GameCooltip:AddLine(actor:Name(), format_func(_, actor.totalabsorbed))\n			Details:AddTooltipBackgroundStatusbar()\n\n			for petIndex, petName in ipairs(actor.pets) do\n				local pet = Combat :GetActor(1, petName)\n				if(pet) then\n				totalAbsorb = totalAbsorb + pet.totalabsorbed\n\n				GameCooltip:AddLine(petName, format_func(_, pet.totalabsorbed))\n				Details:AddTooltipBackgroundStatusbar()\n\n				end\n			end\n		",
			["attribute"] = false,
			["name"] = "Damage on Shields",
			["script"] = "			--get the parameters passed\n			local Combat, CustomContainer, Instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n\n			--do the loop\n			for index, actor in ipairs(Combat:GetActorList(1)) do\n				if(actor:IsPlayer()) then\n\n				--get the actor total damage absorbed\n				local totalAbsorb = actor.totalabsorbed\n\n				--get the damage absorbed by all the actor pets\n				for petIndex, petName in ipairs(actor.pets) do\n					local pet = Combat :GetActor(1, petName)\n					if(pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n					end\n				end\n\n				--add the value to the actor on the custom container\n				CustomContainer:AddValue(actor, totalAbsorb)\n\n				end\n			end\n			--loop end\n\n			--if not managed inside the loop, get the values of total, top and amount\n			total, top = CustomContainer:GetTotalAndHighestValue()\n			amount = CustomContainer:GetNumActors()\n\n			--return the values\n			return total, top, amount\n		",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Holy_PowerWordShield",
			["script_version"] = 1,
		}, -- [11]
	},
	["performance_profiles"] = {
		["Dungeon"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid25"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Arena"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
	},
	["exit_log"] = {
		"1 - Closing Janela Info.", -- [1]
		"2 - Clearing user place from instances.", -- [2]
		"4 - Reversing switches.", -- [3]
		"6 - Saving Config.", -- [4]
		"7 - Saving Profiles.", -- [5]
		"8 - Saving nicktag cache.", -- [6]
	},
	["update_warning_timeout"] = 10,
	["lastUpdateWarning"] = 0,
	["item_level_pool"] = {
		["0x00000000000075C9"] = {
			["name"] = "Boula",
			["time"] = 1680126209,
			["ilvl"] = 354.6666666666667,
		},
		["0x000000000000CC3D"] = {
			["name"] = "Gsee",
			["time"] = 1680125134,
			["ilvl"] = 349.875,
		},
		["0x0000000000012402"] = {
			["time"] = 1680123472,
			["name"] = "Pulposa",
			["ilvl"] = 86.5,
		},
		["0x000000000001069C"] = {
			["time"] = 1680123502,
			["name"] = "Unknown",
			["ilvl"] = 353.3333333333333,
		},
		["0x00000000000121C6"] = {
			["time"] = 1680123457,
			["name"] = "Thror",
			["ilvl"] = 240.0625,
		},
	},
}
