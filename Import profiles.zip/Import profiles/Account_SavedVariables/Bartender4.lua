
Bartender4DB = {
	["namespaces"] = {
		["ActionBars"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 87,
								["x"] = -400,
								["point"] = "BOTTOM",
								["scale"] = 1.300000071525574,
							},
							["padding"] = 0,
							["states"] = {
								["actionbar"] = true,
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -189.5000120019605,
								["x"] = -231.4998348790105,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["rows"] = 12,
							["fadeout"] = true,
							["fadeoutalpha"] = 0,
							["version"] = 3,
							["position"] = {
								["y"] = 145,
								["x"] = -40,
								["point"] = "RIGHT",
							},
							["padding"] = 5,
						}, -- [3]
						{
							["rows"] = 12,
							["fadeout"] = true,
							["fadeoutalpha"] = 0,
							["version"] = 3,
							["position"] = {
								["y"] = 145,
								["x"] = -75,
								["point"] = "RIGHT",
							},
							["padding"] = 5,
						}, -- [4]
						{
							["rows"] = 2,
							["version"] = 3,
							["position"] = {
								["y"] = 131,
								["x"] = 170,
								["point"] = "BOTTOM",
								["scale"] = 1.25,
							},
							["padding"] = 0,
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 131,
								["x"] = -400,
								["point"] = "BOTTOM",
								["scale"] = 1.300000071525574,
							},
							["padding"] = 0,
						}, -- [6]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 0.500003727104513,
								["x"] = -231.4998348790105,
								["point"] = "CENTER",
							},
						}, -- [7]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 38.49997185865095,
								["x"] = -231.4998348790105,
								["point"] = "CENTER",
							},
						}, -- [8]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 76.50001001873056,
								["x"] = -231.4998348790105,
								["point"] = "CENTER",
							},
						}, -- [9]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 114.499978150277,
								["x"] = -231.4998348790105,
								["point"] = "CENTER",
							},
						}, -- [10]
					},
				},
			},
		},
		["ExtraActionBar"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["position"] = {
						["y"] = 222.9999991109659,
						["x"] = -31.4999546934539,
						["point"] = "BOTTOM",
					},
					["version"] = 3,
				},
			},
		},
		["MicroMenu"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["position"] = {
						["y"] = 138.1178306019914,
						["x"] = -291.1748772998221,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.949999988079071,
					},
					["version"] = 3,
					["fadeout"] = true,
					["fadeoutalpha"] = 0,
				},
			},
		},
		["XPBar"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["enabled"] = true,
					["position"] = {
						["y"] = 16.00001094195832,
						["x"] = 337.3334669164078,
						["point"] = "BOTTOMLEFT",
					},
					["version"] = 3,
				},
			},
		},
		["BlizzardArt"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
					["version"] = 3,
				},
			},
		},
		["BagBar"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["enabled"] = false,
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 463.5,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["StanceBar"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["version"] = 3,
					["skin"] = {
						["Zoom"] = true,
					},
					["position"] = {
						["y"] = 167,
						["x"] = -398,
						["point"] = "BOTTOM",
						["scale"] = 1.25,
					},
				},
			},
		},
		["Vehicle"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 51.49999873483603,
						["x"] = 53.50004865752089,
						["point"] = "CENTER",
					},
				},
			},
		},
		["PetBar"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 165.2999716671667,
						["x"] = -153.549954108743,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["RepBar"] = {
			["profiles"] = {
				["Gsea - Maelstrom"] = {
					["position"] = {
						["y"] = 9.999969499291183,
						["x"] = 337.3333268593414,
						["point"] = "LEFT",
					},
					["version"] = 3,
				},
			},
		},
	},
	["profileKeys"] = {
		["Jsea - Maelstrom"] = "Gsea - Maelstrom",
		["Gsea - Maelstrom"] = "Gsea - Maelstrom",
		["Gsee - Maelstrom"] = "Gsea - Maelstrom",
	},
	["profiles"] = {
		["Gsea - Maelstrom"] = {
			["blizzardVehicle"] = true,
			["focuscastmodifier"] = false,
			["onkeydown"] = true,
			["minimapIcon"] = {
				["minimapPos"] = 322.1070835446779,
			},
			["outofrange"] = "hotkey",
		},
	},
}
