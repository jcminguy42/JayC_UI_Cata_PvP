This goes in : WTF\Account\ACCOUNT_NAME\SavedVariables

Replace a shit ton of Character Name inside Bartender4.lua