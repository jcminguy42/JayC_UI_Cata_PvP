This goes in : WTF\Account\ACCOUNT_NAME\SavedVariables

Replace Character Name inside Gladius.lua