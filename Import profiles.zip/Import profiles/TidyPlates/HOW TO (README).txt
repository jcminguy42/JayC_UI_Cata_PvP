#1 goes in your Account Saved Variable
WTF\Account\ACCOUNT_NAME\SavedVariables

In TidyPlates_ThreatPlates.lua -> Replace with your Character Name

#2 goes in your Character Saved Variable
WTF\Account\JCMINGUY42\Maelstrom\Gsea\SavedVariables