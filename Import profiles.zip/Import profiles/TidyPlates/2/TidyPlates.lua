
TidyPlatesOptions = {
	["_EnableMiniButton"] = false,
	["WelcomeShown"] = true,
	["FriendlyAutomation"] = "No Automation",
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Threat Plates",
	["EnableCastWatcher"] = 1,
	["secondary"] = "Threat Plates",
}
