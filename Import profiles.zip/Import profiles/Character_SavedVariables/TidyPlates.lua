
TidyPlatesOptions = {
	["FriendlyAutomation"] = "No Automation",
	["EnableCastWatcher"] = 1,
	["_EnableMiniButton"] = false,
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Threat Plates",
	["WelcomeShown"] = true,
	["secondary"] = "Threat Plates",
}
